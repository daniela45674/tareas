<?php
/**
 * Checkout: valida carrito -> crea pedido (pendiente) -> cobra en la pasarela sandbox
 * -> "webhook" (marcarPedidoComoPagado) descuenta stock y marca pagado.
 * Los precios SIEMPRE se leen de la BD, nunca del navegador (el localStorage se puede manipular).
 */
header('Content-Type: application/json; charset=utf-8');
session_start();
require_once 'conexion.php';
require_once 'includes/pago_simulado.php';
require_once 'includes/pedidos.php';
require_once 'includes/analitica.php';

function salir(int $code, array $data) { http_response_code($code); echo json_encode($data, JSON_UNESCAPED_UNICODE); exit; }

if ($_SERVER['REQUEST_METHOD'] !== 'POST') salir(405, ['ok' => false, 'error' => 'Método no permitido']);
if (empty($_SESSION['usuario_id']))       salir(401, ['ok' => false, 'error' => 'Debes iniciar sesión', 'login' => true]);

$in    = json_decode(file_get_contents('php://input'), true) ?? [];
$items = $in['items'] ?? [];
$card  = $in['pago'] ?? [];
if (!is_array($items) || !$items) salir(422, ['ok' => false, 'error' => 'El carrito está vacío']);

$carrito = [];
foreach ($items as $it) {
    $id = (int)($it['id'] ?? 0); $cant = (int)($it['cantidad'] ?? 0);
    if ($id > 0 && $cant > 0) $carrito[$id] = ($carrito[$id] ?? 0) + $cant;
}
if (!$carrito) salir(422, ['ok' => false, 'error' => 'Carrito inválido']);

try {
    $conexion->beginTransaction();

    // 1) Bloquear filas y validar stock
    $ids = array_keys($carrito);
    $ph  = implode(',', array_fill(0, count($ids), '?'));
    $st  = $conexion->prepare("SELECT id, nombre, precio, precio_oferta, en_oferta, stock FROM productos WHERE activo = 1 AND id IN ($ph) FOR UPDATE");
    $st->execute($ids);
    $prods = [];
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $p) $prods[$p['id']] = $p;

    $total = 0.0; $lineas = [];
    foreach ($carrito as $id => $cant) {
        if (!isset($prods[$id])) throw new RuntimeException('Un producto ya no está disponible.');
        $p = $prods[$id];
        if ($p['stock'] < $cant) throw new RuntimeException("Stock insuficiente de «{$p['nombre']}» (quedan {$p['stock']}).");
        $precio = ($p['en_oferta'] && $p['precio_oferta'] !== null) ? (float)$p['precio_oferta'] : (float)$p['precio'];
        $total += $precio * $cant;
        $lineas[] = ['id' => $id, 'cant' => $cant, 'precio' => $precio];
    }
    $total = round($total, 2);

    // 2) Datos de envío del usuario
    $u = $conexion->prepare("SELECT telefono, direccion FROM usuarios WHERE id = ?");
    $u->execute([$_SESSION['usuario_id']]);
    $user = $u->fetch(PDO::FETCH_ASSOC) ?: ['telefono' => null, 'direccion' => null];

    // 3) Pedido + detalle + pago en estado pendiente
    $conexion->prepare("INSERT INTO pedidos (usuario_id, total, estado, metodo_pago, telefono_contacto, direccion_envio) VALUES (?,?, 'pendiente', 'tarjeta_simulada', ?, ?)")
             ->execute([$_SESSION['usuario_id'], $total, $user['telefono'], $user['direccion']]);
    $pedidoId = (int)$conexion->lastInsertId();
    $insDet = $conexion->prepare("INSERT INTO detalle_pedidos (pedido_id, producto_id, cantidad, precio_unitario) VALUES (?,?,?,?)");
    foreach ($lineas as $l) $insDet->execute([$pedidoId, $l['id'], $l['cant'], $l['precio']]);
    $conexion->prepare("INSERT INTO pagos (pedido_id, proveedor, monto, moneda, estado) VALUES (?, 'simulado', ?, 'PEN', 'pendiente')")
             ->execute([$pedidoId, $total]);

    // 4) Cobro en la pasarela sandbox
    $pago = simularPago($total, 'PEN', (string)($card['numero'] ?? ''), (string)($card['vencimiento'] ?? ''), (string)($card['cvv'] ?? ''));

    if (!$pago['exito']) {
        $conexion->prepare("UPDATE pagos SET estado='rechazado', tarjeta_ult4=?, mensaje=? WHERE pedido_id=?")
                 ->execute([$pago['ult4'], $pago['mensaje'], $pedidoId]);
        $conexion->prepare("UPDATE pedidos SET estado='cancelado' WHERE id=?")->execute([$pedidoId]);
        $conexion->commit();
        registrarEvento($conexion, 'pedido_generado', ['pedido_id' => $pedidoId, 'total' => $total]);
        registrarEvento($conexion, 'pago_rechazado', ['pedido_id' => $pedidoId, 'motivo' => $pago['motivo']]);
        salir(402, ['ok' => false, 'error' => 'Pago rechazado: ' . $pago['mensaje'], 'pedido_id' => $pedidoId]);
    }

    // 5) "Webhook": marca pagado + descuenta stock
    marcarPedidoComoPagado($conexion, $pedidoId, [
        'referencia' => $pago['referencia'], 'ult4' => $pago['ult4'], 'mensaje' => $pago['mensaje'],
        'metodo' => 'tarjeta_simulada', 'proveedor' => 'simulado',
    ]);
    $conexion->commit();

    registrarEvento($conexion, 'pedido_generado', ['pedido_id' => $pedidoId, 'total' => $total]);
    registrarEvento($conexion, 'pago_exitoso', ['pedido_id' => $pedidoId, 'total' => $total, 'referencia' => $pago['referencia']]);
    salir(200, ['ok' => true, 'pedido_id' => $pedidoId, 'total' => $total, 'referencia' => $pago['referencia']]);

} catch (RuntimeException $e) {
    if ($conexion->inTransaction()) $conexion->rollBack();
    salir(409, ['ok' => false, 'error' => $e->getMessage()]);
} catch (Throwable $e) {
    if ($conexion->inTransaction()) $conexion->rollBack();
    error_log($e->getMessage());
    salir(500, ['ok' => false, 'error' => 'Error interno al procesar la compra']);
}
