<?php
session_start();
include 'conexion.php';

$error = "";

// A dónde volver después de iniciar sesión (lista blanca: evita redirecciones a sitios externos)
$permitidos = ['carrito.php', 'productos.php', 'home.php', 'mis_pedidos.php'];
$volver  = $_POST['volver'] ?? ($_GET['volver'] ?? '');
if (!in_array($volver, $permitidos, true)) $volver = '';
$destino = $volver !== '' ? $volver : 'home.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (!empty($email) && !empty($password)) {
        $sql = "SELECT * FROM usuarios WHERE email = ?";
        $stmt = $conexion->prepare($sql);
        $stmt->execute([$email]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($usuario && password_verify($password, $usuario['password'])) {
            session_regenerate_id(true); // evita fijación de sesión
            $_SESSION['usuario_id'] = $usuario['id'];
            $_SESSION['nombre'] = $usuario['nombre'];
            $_SESSION['rol'] = $usuario['rol'];

            if ($usuario['rol'] === 'admin') {
                header("Location: admin/admin.php");
            } else {
                header("Location: " . $destino);
            }
            exit();
        } else {
            $error = "Correo o contraseña incorrectos.";
        }
    } else {
        $error = "Por favor, completa todos los campos.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión - Patitas Felices</title>
    <link rel="stylesheet" href="css/style_auth.css">
    <style>
        /* Estilo para el contenedor del campo de contraseña y el botón del ojo */
        .password-container {
            position: relative;
            display: flex;
            align-items: center;
        }
        .password-container input {
            width: 100%;
            padding-right: 40px; /* Espacio para que el texto no quede debajo del icono */
        }
        .toggle-password {
            position: absolute;
            right: 12px;
            background: none;
            border: none;
            cursor: pointer;
            font-size: 16px;
            color: #777;
            padding: 0;
        }
        .toggle-password:hover {
            color: #ff7f00;
        }
    </style>
</head>
<body>
    <div class="container-auth">
        <h2>Iniciar Sesión</h2>

        <?php if (isset($_GET['registro']) && $_GET['registro'] == 'exitoso'): ?>
            <div class="success-msg">¡Registro exitoso! Ahora puedes iniciar sesión.</div>
        <?php endif; ?>

        <?php if ($volver !== '' && $_SERVER['REQUEST_METHOD'] !== 'POST'): ?>
            <div class="error-msg">Inicia sesión para continuar con tu compra.</div>
        <?php endif; ?>

        <?php if (!empty($error)): ?>
            <div class="error-msg"><?php echo $error; ?></div>
        <?php endif; ?>

        <form action="login.php" method="POST">
            <input type="hidden" name="volver" value="<?php echo htmlspecialchars($volver); ?>">
            <div class="form-group">
                <label>Correo Electrónico:</label>
                <input type="email" name="email" required>
            </div>
            <div class="form-group">
                <label>Contraseña:</label>
                <div class="password-container">
                    <input type="password" name="password" id="password" required>
                    <button type="button" class="toggle-password" onclick="togglePassword()">👁️</button>
                </div>
            </div>
            <button type="submit" class="btn-submit">Ingresar</button>
        </form>
        <p>¿No tienes cuenta? <a href="registro.php">Regístrate aquí</a></p>
    </div>

    <script>
        function togglePassword() {
            const passwordInput = document.getElementById('password');
            const toggleBtn = document.querySelector('.toggle-password');
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleBtn.textContent = '🙈'; // Cambia el icono a ojos cerrados/oculto
            } else {
                passwordInput.type = 'password';
                toggleBtn.textContent = '👁️'; // Vuelve al icono de ojo
            }
        }
    </script>
<p style="text-align:center;font-size:.85rem;margin-top:14px"><a href="privacidad.php">Política de Privacidad</a> · <a href="terminos.php">Términos de Servicio</a></p>
</body>
</html>