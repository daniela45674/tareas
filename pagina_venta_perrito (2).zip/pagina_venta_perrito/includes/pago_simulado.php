<?php
/**
 * Pasarela de pago SANDBOX (misma idea que Stripe en modo test):
 *  1. Valida el número con el algoritmo de Luhn (el real de las tarjetas).
 *  2. Valida vencimiento (MM/AA, no vencida) y CVV.
 *  3. Tarjetas de prueba: 4242 4242 4242 4242 éxito · 4000 0000 0000 0002 rechazada · 4000 0000 0000 9995 sin fondos.
 *  4. Cualquier otra tarjeta válida por Luhn se trata como éxito (para no bloquear pruebas).
 *  5. Simula la latencia de red de un cobro real.
 * Para pasar a una pasarela real (Stripe/Culqi/Mercado Pago) solo se reemplaza esta función.
 */
const TARJETAS_DE_PRUEBA = [
    '4242424242424242' => 'exito',
    '4000000000000002' => 'rechazada',
    '4000000000009995' => 'fondos_insuficientes',
];
const MENSAJES_RECHAZO = [
    'numero_invalido'      => 'El número de tarjeta no es válido (no pasa la verificación de Luhn).',
    'datos_invalidos'      => 'Vencimiento o CVV inválidos.',
    'tarjeta_vencida'      => 'La tarjeta está vencida.',
    'rechazada'            => 'Tu banco rechazó la operación (tarjeta de prueba de rechazo).',
    'fondos_insuficientes' => 'Fondos insuficientes (tarjeta de prueba).',
    'monto_invalido'       => 'Monto inválido.',
];

function validarLuhn(string $numero): bool
{
    if (!preg_match('/^\d{13,19}$/', $numero)) return false;
    $suma = 0; $alternar = false;
    for ($i = strlen($numero) - 1; $i >= 0; $i--) {
        $d = (int)$numero[$i];
        if ($alternar) { $d *= 2; if ($d > 9) $d -= 9; }
        $suma += $d;
        $alternar = !$alternar;
    }
    return $suma % 10 === 0;
}

function simularPago(float $monto, string $moneda, string $numeroTarjeta, string $vencimiento, string $cvv): array
{
    usleep(random_int(600, 1200) * 1000); // latencia simulada

    $num  = preg_replace('/\D/', '', $numeroTarjeta);
    $ult4 = substr($num, -4);
    $rech = fn(string $motivo) => ['exito' => false, 'estado' => 'rechazado', 'motivo' => $motivo,
                                   'mensaje' => MENSAJES_RECHAZO[$motivo], 'referencia' => null, 'ult4' => $ult4];

    if ($monto <= 0) return $rech('monto_invalido');
    if (!validarLuhn($num)) return $rech('numero_invalido');

    $v = str_replace([' ', '/'], '', $vencimiento);
    if (!preg_match('/^(0[1-9]|1[0-2])\d{2}$/', $v) || !preg_match('/^\d{3,4}$/', $cvv)) return $rech('datos_invalidos');
    $mes = (int)substr($v, 0, 2); $anio = 2000 + (int)substr($v, 2, 2);
    if ($anio < (int)date('Y') || ($anio === (int)date('Y') && $mes < (int)date('n'))) return $rech('tarjeta_vencida');

    $escenario = TARJETAS_DE_PRUEBA[$num] ?? 'exito';
    if ($escenario !== 'exito') return $rech($escenario);

    return ['exito' => true, 'estado' => 'aprobado', 'motivo' => null, 'mensaje' => 'Pago aprobado',
            'referencia' => 'sim_' . strtolower(bin2hex(random_bytes(6))), 'ult4' => $ult4];
}
