<footer class="footer">
    <div class="footer-contenido">

        <div class="footer-col">
            <img src="imagenes/otras_imagenes/logo2.jpg" class="footer-logo" alt="Logo Patitas Felices">
            <p>&copy; <?php echo date("Y"); ?> Patitas Felices</p>
        </div>

        <div class="footer-col">
            <h3>Contacto</h3>
            <p>Email: patitasfelices@gmail.com</p>
            <p>WhatsApp: <a href="https://wa.me/51901023589" target="_blank" rel="noopener">901 023 589</a></p>
            <p>Tienda 100% en línea (sin local físico)</p>
        </div>

        <div class="footer-col">
            <h3>Enlaces</h3>
            <ul class="footer-links">
                <li><a href="home.php">Inicio</a></li>
                <li><a href="productos.php">Productos</a></li>
                <li><a href="carrito.php">Carrito</a></li>
                <li><a href="nosotros.php">Contacto</a></li>
                <li><a href="privacidad.php">Política de Privacidad</a></li>
                <li><a href="terminos.php">Términos de Servicio</a></li>
            </ul>
        </div>

        <div class="footer-col redes-sociales-col">
            <h3>Síguenos</h3>
            <div class="redes-iconos">
                <a href="https://www.facebook.com/tucuennnnta" target="_blank" rel="noopener">
                    <img src="imagenes/otras_imagenes/faceboock.png" alt="Facebook"> Facebook
                </a>
                <a href="https://www.instagram.com/tucuennnnta" target="_blank" rel="noopener">
                    <img src="imagenes/otras_imagenes/instagran.png" alt="Instagram"> Instagram
                </a>
                <a href="https://www.twitter.com/tucuennnnta" target="_blank" rel="noopener">
                    <img src="imagenes/otras_imagenes/x.png" alt="Twitter"> Twitter
                </a>
            </div>
        </div>

    </div>

    <div class="copyright-mobile">
        <p>&copy; <?php echo date("Y"); ?> Patitas Felices ·
           <a href="privacidad.php">Privacidad</a> · <a href="terminos.php">Términos</a></p>
    </div>
</footer>
