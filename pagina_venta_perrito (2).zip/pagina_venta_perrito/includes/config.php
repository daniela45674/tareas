<?php
// Secreto compartido para el webhook de pagos (api/webhook_pago.php).
// CÁMBIALO por una cadena larga y aleatoria. Mientras tenga el valor de ejemplo, el webhook responde 503.
define('WEBHOOK_SECRET', 'cambia-esto-por-un-secreto-largo');
