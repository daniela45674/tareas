<?php
/** Registra un evento de negocio. Nunca debe romper la página: si falla, solo se escribe en el log. */
function registrarEvento(PDO $c, string $tipo, array $detalle = [], ?string $pagina = null): void
{
    try {
        $c->prepare("INSERT INTO eventos (tipo, detalle, pagina, usuario_id) VALUES (?,?,?,?)")
          ->execute([
              substr($tipo, 0, 40),
              json_encode($detalle, JSON_UNESCAPED_UNICODE),
              $pagina !== null ? substr($pagina, 0, 80) : null,
              $_SESSION['usuario_id'] ?? null,
          ]);
    } catch (Throwable $e) {
        error_log('analitica: ' . $e->getMessage());
    }
}
