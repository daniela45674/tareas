<?php
// Menú compartido. Cada página define $paginaActual antes de incluirlo.
$paginaActual = $paginaActual ?? '';
$estaLogueado = !empty($_SESSION['usuario_id']);
$esAdmin      = ($_SESSION['rol'] ?? '') === 'admin';
$activo = fn(string $p) => $paginaActual === $p ? ' style="color:#e11d48;font-weight:bold"' : '';
?>
<nav id="menu" class="menu">
    <ul>
        <li><a href="home.php"<?= $activo('home') ?>>Inicio</a></li>
        <li><a href="productos.php"<?= $activo('productos') ?>>Productos</a></li>
        <li>
            <a href="carrito.php"<?= $activo('carrito') ?>>
                <img src="imagenes/otras_imagenes/carrito.png" class="icono-carrito" alt="Carrito">
            </a>
        </li>
        <li><a href="nosotros.php"<?= $activo('nosotros') ?>>Contacto</a></li>
        <?php if ($estaLogueado): ?>
            <li><a href="mis_pedidos.php"<?= $activo('pedidos') ?>>Mis pedidos</a></li>
            <?php if ($esAdmin): ?><li><a href="admin/admin.php">Administración</a></li><?php endif; ?>
            <li><a href="logout.php" class="btn-login-menu">Salir (<?= htmlspecialchars(explode(' ', (string)($_SESSION['nombre'] ?? ''))[0]) ?>)</a></li>
        <?php else: ?>
            <li><a href="login.php" class="btn-login-menu">Ingresar</a></li>
        <?php endif; ?>
    </ul>
</nav>
