<?php
/**
 * "Webhook" de pago: marca el pedido como pagado, descuenta el stock y registra los movimientos.
 * Es idempotente (si el pedido ya está pagado no hace nada), como debe ser un webhook real,
 * porque las pasarelas pueden reenviar la misma notificación varias veces.
 *
 * Debe llamarse DENTRO de una transacción abierta por quien la invoca
 * (procesar_compra.php en el flujo normal, api/webhook_pago.php cuando lo llama una pasarela real).
 */
function marcarPedidoComoPagado(PDO $c, int $pedidoId, array $d = []): array
{
    $st = $c->prepare("SELECT id, estado FROM pedidos WHERE id = ? FOR UPDATE");
    $st->execute([$pedidoId]);
    $pedido = $st->fetch(PDO::FETCH_ASSOC);
    if (!$pedido) throw new RuntimeException('El pedido no existe.');
    if ($pedido['estado'] === 'pagado') return ['pedido_id' => $pedidoId, 'ya_pagado' => true];
    if ($pedido['estado'] === 'cancelado') throw new RuntimeException('El pedido está cancelado.');

    $det = $c->prepare("SELECT producto_id, cantidad FROM detalle_pedidos WHERE pedido_id = ? ORDER BY producto_id");
    $det->execute([$pedidoId]);

    $lock = $c->prepare("SELECT stock FROM productos WHERE id = ? FOR UPDATE");
    $upd  = $c->prepare("UPDATE productos SET stock = stock - ? WHERE id = ? AND stock >= ?");
    $mov  = $c->prepare("INSERT INTO movimientos_stock (producto_id, pedido_id, tipo, cantidad, stock_resultante) VALUES (?,?, 'venta', ?, ?)");

    foreach ($det->fetchAll(PDO::FETCH_ASSOC) as $l) {
        $lock->execute([$l['producto_id']]);
        $stock = (int)$lock->fetchColumn();
        if ($stock < (int)$l['cantidad']) throw new RuntimeException("Stock insuficiente para el producto #{$l['producto_id']}.");
        $upd->execute([$l['cantidad'], $l['producto_id'], $l['cantidad']]);
        $mov->execute([$l['producto_id'], $pedidoId, -(int)$l['cantidad'], $stock - (int)$l['cantidad']]);
    }

    $c->prepare("UPDATE pedidos SET estado = 'pagado', metodo_pago = ? WHERE id = ?")
      ->execute([$d['metodo'] ?? 'tarjeta_simulada', $pedidoId]);
    $c->prepare("UPDATE pagos SET estado = 'aprobado', referencia = ?, tarjeta_ult4 = ?, mensaje = ?, proveedor = ? WHERE pedido_id = ?")
      ->execute([$d['referencia'] ?? null, $d['ult4'] ?? null, $d['mensaje'] ?? 'Pago aprobado', $d['proveedor'] ?? 'simulado', $pedidoId]);

    return ['pedido_id' => $pedidoId, 'ya_pagado' => false];
}
