<?php
session_start();
include '../conexion.php';
if (!isset($_SESSION['usuario_id']) || ($_SESSION['rol'] ?? '') !== 'admin') { header("Location: ../login.php"); exit(); }
if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reiniciar']) && hash_equals($_SESSION['csrf'], $_POST['csrf'] ?? '')) {
    $conexion->exec("DELETE FROM eventos");
    header("Location: admin_panel.php"); exit();
}

$cnt = $conexion->query("SELECT tipo, COUNT(*) FROM eventos GROUP BY tipo")->fetchAll(PDO::FETCH_KEY_PAIR);
$n = fn($t) => (int)($cnt[$t] ?? 0);

$ped = $conexion->query("SELECT COUNT(*) total, SUM(estado='pagado') pagados, SUM(estado='cancelado') cancelados,
                                COALESCE(SUM(CASE WHEN estado='pagado' THEN total END),0) ingresos FROM pedidos")->fetch(PDO::FETCH_ASSOC);
$sinResp  = (int)$conexion->query("SELECT COUNT(*) FROM eventos WHERE tipo='chatbot_pregunta' AND detalle LIKE '%\"tipoRespuesta\":\"sin_respuesta\"%'")->fetchColumn();
$chatTot  = $n('chatbot_pregunta');
$tasaChat = $chatTot ? (($chatTot - $sinResp) / $chatTot) * 100 : 0;
$tasaConv = $n('agregar_carrito') ? min(100, ((int)$ped['pagados'] / $n('agregar_carrito')) * 100) : 0;

// Más agregados al carrito (desde eventos)
$top = [];
foreach ($conexion->query("SELECT detalle FROM eventos WHERE tipo='agregar_carrito' ORDER BY id DESC LIMIT 1000")->fetchAll(PDO::FETCH_COLUMN) as $j) {
    $d = json_decode($j, true); $nom = $d['producto'] ?? 'Sin nombre'; $top[$nom] = ($top[$nom] ?? 0) + 1;
}
arsort($top); $top = array_slice($top, 0, 8, true); $maxTop = max(1, ...array_values($top ?: [0]));

$vendidos = $conexion->query("SELECT pr.nombre, SUM(dp.cantidad) uds FROM detalle_pedidos dp JOIN pedidos pe ON pe.id=dp.pedido_id AND pe.estado='pagado'
                              JOIN productos pr ON pr.id=dp.producto_id GROUP BY pr.id ORDER BY uds DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
$stockBajo = $conexion->query("SELECT nombre, stock, stock_minimo FROM productos WHERE activo=1 AND stock <= stock_minimo ORDER BY stock ASC LIMIT 10")->fetchAll(PDO::FETCH_ASSOC);
$pedidos = $conexion->query("SELECT pe.id, u.nombre cliente, pe.total, pe.estado, pe.estado_envio, pg.estado pago_estado, pg.referencia, pg.tarjeta_ult4
                             FROM pedidos pe JOIN usuarios u ON u.id=pe.usuario_id LEFT JOIN pagos pg ON pg.pedido_id=pe.id
                             ORDER BY pe.id DESC LIMIT 15")->fetchAll(PDO::FETCH_ASSOC);
$eventos = $conexion->query("SELECT id, tipo, detalle, pagina, created_at FROM eventos ORDER BY id DESC LIMIT 20")->fetchAll(PDO::FETCH_ASSOC);
$h = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="es"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Panel de Control - Patitas Felices</title>
<style>
 body{font-family:system-ui,sans-serif;max-width:1000px;margin:0 auto;padding:0 20px 60px;color:#1f2937;background:#fafafa;line-height:1.5}
 h1{font-size:1.4rem;margin-bottom:4px} h2{font-size:1.1rem;margin-top:32px;padding-top:10px;border-top:1px solid #e5e7eb}
 .kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin:16px 0}
 .kpi{background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:14px;text-align:center}
 .kpi .v{font-size:1.5rem;font-weight:700;color:#c2410c}.kpi .e{font-size:.75rem;color:#6b7280;text-transform:uppercase}
 .fila{display:flex;align-items:center;gap:10px;margin:6px 0;font-size:.85rem}.fila .nom{width:220px;flex-shrink:0}
 .fondo{flex:1;background:#f0f0f0;border-radius:4px;height:18px;overflow:hidden}.relleno{background:#f29b2e;height:100%}
 .funnel{display:flex;gap:10px;flex-wrap:wrap}.paso{background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:12px 18px;text-align:center;flex:1;min-width:130px}
 .paso .v{font-size:1.4rem;font-weight:700;color:#166534}
 table{width:100%;border-collapse:collapse;font-size:.82rem;background:#fff;margin:10px 0}th,td{border:1px solid #e5e7eb;padding:6px 8px;text-align:left}th{background:#f3f4f6}
 .pagado{color:#166534;font-weight:600}.pendiente{color:#92400e;font-weight:600}.cancelado,.rechazado{color:#991b1b;font-weight:600}
 .btn{background:#f29b2e;color:#fff;border:none;padding:9px 16px;border-radius:6px;cursor:pointer;font-weight:600;text-decoration:none;display:inline-block}
 .btn.p{background:#fee2e2;color:#991b1b}
</style></head><body>
<p><a href="admin.php">⬅ Volver al Panel</a></p>
<h1>📊 Panel de Control — Patitas Felices</h1>
<p style="color:#6b7280;margin-top:0">Indicadores calculados desde la base de datos (eventos, pedidos y pagos).</p>
<a class="btn" href="admin_panel.php">🔄 Refrescar</a>
<form method="POST" style="display:inline" onsubmit="return confirm('¿Borrar todos los eventos registrados?')">
  <input type="hidden" name="csrf" value="<?= $h($_SESSION['csrf']) ?>"><button class="btn p" name="reiniciar" value="1">🗑️ Reiniciar eventos</button></form>

<h2>Indicadores clave</h2>
<div class="kpis">
  <div class="kpi"><div class="v"><?= $n('visita') ?></div><div class="e">Visitas</div></div>
  <div class="kpi"><div class="v"><?= $n('agregar_carrito') ?></div><div class="e">Agregados al carrito</div></div>
  <div class="kpi"><div class="v"><?= $n('clic_whatsapp') ?></div><div class="e">Clics WhatsApp</div></div>
  <div class="kpi"><div class="v"><?= $n('busqueda_catalogo') ?></div><div class="e">Búsquedas</div></div>
  <div class="kpi"><div class="v"><?= (int)$ped['total'] ?></div><div class="e">Pedidos generados</div></div>
  <div class="kpi"><div class="v"><?= (int)$ped['pagados'] ?></div><div class="e">Pedidos pagados</div></div>
  <div class="kpi"><div class="v">S/ <?= number_format((float)$ped['ingresos'], 2) ?></div><div class="e">Ingresos</div></div>
  <div class="kpi"><div class="v"><?= $n('pago_rechazado') ?></div><div class="e">Pagos rechazados</div></div>
  <div class="kpi"><div class="v"><?= $chatTot ?></div><div class="e">Preguntas al asistente</div></div>
  <div class="kpi"><div class="v"><?= round($tasaChat) ?>%</div><div class="e">Resolución del asistente</div></div>
</div>

<h2>Embudo de conversión</h2>
<div class="funnel">
  <div class="paso"><div class="v"><?= $n('visita') ?></div>Visitas</div>
  <div class="paso"><div class="v"><?= $n('agregar_carrito') ?></div>Agregaron al carrito</div>
  <div class="paso"><div class="v"><?= (int)$ped['total'] ?></div>Generaron pedido</div>
  <div class="paso"><div class="v"><?= (int)$ped['pagados'] ?></div>Pagaron</div>
  <div class="paso"><div class="v"><?= number_format($tasaConv, 1) ?>%</div>Conversión (carrito → pago)</div>
</div>

<h2>Productos más agregados al carrito</h2>
<?php foreach ($top as $nom => $veces): ?>
  <div class="fila"><span class="nom"><?= $h($nom) ?></span><div class="fondo"><div class="relleno" style="width:<?= ($veces / $maxTop) * 100 ?>%"></div></div><span><?= $veces ?></span></div>
<?php endforeach; if (!$top) echo '<p style="color:#9ca3af">(sin datos todavía)</p>'; ?>

<h2>Más vendidos (pedidos pagados)</h2>
<table><tr><th>Producto</th><th>Unidades</th></tr>
<?php foreach ($vendidos as $v): ?><tr><td><?= $h($v['nombre']) ?></td><td><?= (int)$v['uds'] ?></td></tr><?php endforeach; if (!$vendidos) echo '<tr><td colspan="2" style="color:#9ca3af">(sin ventas todavía)</td></tr>'; ?></table>

<h2>⚠️ Stock bajo</h2>
<table><tr><th>Producto</th><th>Stock</th><th>Mínimo</th></tr>
<?php foreach ($stockBajo as $s): ?><tr><td><?= $h($s['nombre']) ?></td><td class="<?= $s['stock'] == 0 ? 'rechazado' : 'pendiente' ?>"><?= (int)$s['stock'] ?></td><td><?= (int)$s['stock_minimo'] ?></td></tr><?php endforeach; if (!$stockBajo) echo '<tr><td colspan="3" style="color:#9ca3af">Todo el stock está sobre el mínimo ✔</td></tr>'; ?></table>

<h2>Pedidos y pagos (últimos 15)</h2>
<table><tr><th>Pedido</th><th>Cliente</th><th>Total</th><th>Estado pedido</th><th>Estado pago</th><th>Envío</th><th>Transacción</th></tr>
<?php foreach ($pedidos as $p): ?>
<tr><td>#<?= (int)$p['id'] ?></td><td><?= $h($p['cliente']) ?></td><td>S/ <?= number_format((float)$p['total'], 2) ?></td>
<td class="<?= $h($p['estado']) ?>"><?= $h($p['estado']) ?></td><td class="<?= $h($p['pago_estado'] === 'aprobado' ? 'pagado' : $p['pago_estado']) ?>"><?= $h($p['pago_estado'] ?? '—') ?></td>
<td><?= $h($p['estado_envio']) ?></td><td><?= $h($p['referencia'] ?? '—') ?><?= $p['tarjeta_ult4'] ? ' · ****' . $h($p['tarjeta_ult4']) : '' ?></td></tr>
<?php endforeach; if (!$pedidos) echo '<tr><td colspan="7" style="color:#9ca3af">(sin pedidos todavía)</td></tr>'; ?></table>

<h2>Registro de eventos (últimos 20)</h2>
<table><tr><th>#</th><th>Tipo</th><th>Detalle</th><th>Página</th><th>Fecha</th></tr>
<?php foreach ($eventos as $e): ?><tr><td><?= (int)$e['id'] ?></td><td><?= $h($e['tipo']) ?></td><td><?= $h($e['detalle']) ?></td><td><?= $h($e['pagina']) ?></td><td><?= $h($e['created_at']) ?></td></tr><?php endforeach; if (!$eventos) echo '<tr><td colspan="5" style="color:#9ca3af">(vacío)</td></tr>'; ?></table>
</body></html>
