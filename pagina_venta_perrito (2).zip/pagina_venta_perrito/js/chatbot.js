// Widget del asistente virtual (se inyecta solo, no necesita HTML extra). Habla con api/chatbot.php.
(function () {
    const css = `
    #cb-btn{position:fixed;left:18px;bottom:18px;width:54px;height:54px;border-radius:50%;border:none;background:#f29b2e;color:#fff;font-size:26px;cursor:pointer;z-index:9998;box-shadow:0 4px 12px rgba(0,0,0,.25)}
    #cb-box{position:fixed;left:18px;bottom:84px;width:min(340px,92vw);height:420px;background:#fff;border-radius:12px;box-shadow:0 8px 28px rgba(0,0,0,.28);display:none;flex-direction:column;overflow:hidden;z-index:9998;font-family:inherit}
    #cb-box.abierto{display:flex}
    #cb-head{background:#f29b2e;color:#fff;padding:12px 14px;font-weight:bold}
    #cb-log{flex:1;overflow-y:auto;padding:12px;background:#fafafa}
    .cb-m{max-width:85%;padding:8px 12px;border-radius:12px;margin:6px 0;font-size:14px;line-height:1.4;word-wrap:break-word}
    .cb-bot{background:#a72525;border:1px solid #971010}.cb-yo{background:#f29b2e;color:#fff;margin-left:auto}
    #cb-form{display:flex;border-top:1px solid #eee}
    #cb-in{flex:1;border:none;padding:12px;font-size:14px;outline:none}
    #cb-send{border:none;background:#fff;color:#f29b2e;font-weight:bold;padding:0 14px;cursor:pointer}`;
    const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);

    const btn = document.createElement('button'); btn.id = 'cb-btn'; btn.type = 'button'; btn.textContent = '🐶'; btn.title = 'Asistente virtual';
    const box = document.createElement('div'); box.id = 'cb-box';
    box.innerHTML = '<div id="cb-head">Asistente Patitas 🐾</div><div id="cb-log"></div>' +
        '<div id="cb-form"><input id="cb-in" maxlength="300" placeholder="Pregúntame algo…" autocomplete="off"><button id="cb-send" type="button">Enviar</button></div>';
    document.body.append(btn, box);

    const log = box.querySelector('#cb-log'), input = box.querySelector('#cb-in');

    function agregar(texto, clase) {
        const d = document.createElement('div'); d.className = 'cb-m ' + clase;
        // textContent + enlaces creados a mano: así nada de lo que escriba el usuario o el servidor se ejecuta como HTML
        texto.split(/(https?:\/\/\S+)/g).forEach(parte => {
            if (/^https?:\/\//.test(parte)) {
                const a = document.createElement('a'); a.href = parte; a.target = '_blank'; a.rel = 'noopener'; a.textContent = parte; d.appendChild(a);
            } else d.appendChild(document.createTextNode(parte));
        });
        log.appendChild(d); log.scrollTop = log.scrollHeight;
    }
    async function enviar() {
        const t = input.value.trim(); if (!t) return;
        agregar(t, 'cb-yo'); input.value = '';
        try {
            const r = await fetch('api/chatbot.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ mensaje: t }) });
            const d = await r.json(); agregar(d.respuesta || 'Sin respuesta.', 'cb-bot');
        } catch (e) { agregar('No pude conectarme. Escríbenos por WhatsApp 🙏', 'cb-bot'); }
    }
    btn.addEventListener('click', () => {
        box.classList.toggle('abierto');
        if (box.classList.contains('abierto') && !log.children.length) agregar('¡Hola! Soy el asistente de Patitas Felices 🐾 Pregúntame por productos, ofertas, envíos o pagos.', 'cb-bot');
        input.focus();
    });
    box.querySelector('#cb-send').addEventListener('click', enviar);
    input.addEventListener('keydown', e => { if (e.key === 'Enter') enviar(); });
})();
