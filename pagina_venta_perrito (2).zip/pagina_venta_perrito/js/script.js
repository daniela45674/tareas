// ==========================================
// 1. MENÚ HAMBURGUESA
// ==========================================
const hamburger = document.getElementById('hamburger');
const menu = document.getElementById('menu');

if (hamburger && menu) {
    hamburger.addEventListener('click', function() {
        menu.classList.toggle('activo');
        menu.classList.toggle('mobile');
        hamburger.classList.toggle('active');
    });

    const menuLinks = menu.querySelectorAll('a');
    menuLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (window.innerWidth <= 900) {
                menu.classList.remove('activo', 'mobile');
                hamburger.classList.remove('active');
            }
        });
    });

    document.addEventListener('click', function(event) {
        const isClickInsideMenu = menu.contains(event.target);
        const isClickOnHamburger = hamburger.contains(event.target);
        
        if (!isClickInsideMenu && !isClickOnHamburger && menu.classList.contains('activo')) {
            menu.classList.remove('activo', 'mobile');
            hamburger.classList.remove('active');
        }
    });
}

// ==========================================
// 2. CARRUSEL PRINCIPAL
// ==========================================
document.addEventListener("DOMContentLoaded", () => {
    const items = document.querySelectorAll(".carousel-item");
    const indicators = document.querySelectorAll(".carousel-indicators .indicator");
    const nextBtn = document.getElementById("nextSlideBtn");
    const prevBtn = document.getElementById("prevSlideBtn");
    
    if (items.length > 0) {
        let currentIndex = 0;
        let autoSlideInterval;

        function showSlide(index) {
            if (index >= items.length) {
                currentIndex = 0;
            } else if (index < 0) {
                currentIndex = items.length - 1;
            } else {
                currentIndex = index;
            }

            items.forEach((item, i) => {
                item.classList.toggle("active", i === currentIndex);
            });

            indicators.forEach((ind, i) => {
                ind.classList.toggle("active", i === currentIndex);
            });
        }

        function nextSlide() {
            showSlide(currentIndex + 1);
        }

        function prevSlide() {
            showSlide(currentIndex - 1);
        }

        if (nextBtn) nextBtn.addEventListener("click", () => {
            nextSlide();
            resetTimer();
        });

        if (prevBtn) prevBtn.addEventListener("click", () => {
            prevSlide();
            resetTimer();
        });

        indicators.forEach((ind) => {
            ind.addEventListener("click", (e) => {
                const index = parseInt(e.target.getAttribute("data-index"));
                showSlide(index);
                resetTimer();
            });
        });

        function startTimer() {
            autoSlideInterval = setInterval(nextSlide, 50000);
        }

        function resetTimer() {
            clearInterval(autoSlideInterval);
            startTimer();
        }

        const carouselContainer = document.querySelector(".carousel");
        if (carouselContainer) {
            carouselContainer.addEventListener("mouseenter", () => clearInterval(autoSlideInterval));
            carouselContainer.addEventListener("mouseleave", startTimer);
        }

        startTimer();
    }
});

// ==========================================
// 3. CARRUSEL MULTIIMAGEN (OFERTAS)
// ==========================================
const contenedorMulti = document.getElementById("contenedorMulti");
if (contenedorMulti) {
    let indexMulti = 0;
    const slidesMulti = document.querySelectorAll(".slide-multi");
    const totalSlides = slidesMulti.length;

    function getSlidesVisibles() {
        const width = window.innerWidth;
        if (width > 980) {
            return 3;
        } else if (width > 620) {
            return 2;
        } else {
            return 1;
        }
    }

    function actualizarMulti() {
        const visibles = getSlidesVisibles();
        const maxIndex = totalSlides - visibles;
        
        if (indexMulti > maxIndex) {
            indexMulti = 0;
        } else if (indexMulti < 0) {
            indexMulti = maxIndex;
        }

        const desplazamiento = indexMulti * (100 / visibles);
        contenedorMulti.style.transform = `translateX(-${desplazamiento}%)`;
    }

    const nextBtnMulti = document.getElementById("next");
    const prevBtnMulti = document.getElementById("prev");

    if (nextBtnMulti) {
        nextBtnMulti.addEventListener("click", () => {
            const visibles = getSlidesVisibles();
            const maxIndex = totalSlides - visibles;
            indexMulti++;
            if (indexMulti > maxIndex) {
                indexMulti = 0;
            }
            actualizarMulti();
            reiniciarAutoplay();
        });
    }

    if (prevBtnMulti) {
        prevBtnMulti.addEventListener("click", () => {
            const visibles = getSlidesVisibles();
            const maxIndex = totalSlides - visibles;
            indexMulti--;
            if (indexMulti < 0) {
                indexMulti = maxIndex;
            }
            actualizarMulti();
            reiniciarAutoplay();
        });
    }

    let autoplayInterval = setInterval(() => {
        const visibles = getSlidesVisibles();
        const maxIndex = totalSlides - visibles;
        indexMulti++;
        if (indexMulti > maxIndex) {
            indexMulti = 0;
        }
        actualizarMulti();
    }, 4000);

    function reiniciarAutoplay() {
        clearInterval(autoplayInterval);
        autoplayInterval = setInterval(() => {
            const visibles = getSlidesVisibles();
            const maxIndex = totalSlides - visibles;
            indexMulti++;
            if (indexMulti > maxIndex) {
                indexMulti = 0;
            }
            actualizarMulti();
        }, 4000);
    }

    contenedorMulti.addEventListener("mouseenter", () => clearInterval(autoplayInterval));
    contenedorMulti.addEventListener("mouseleave", () => reiniciarAutoplay());

    let resizeTimer;
    window.addEventListener("resize", () => {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(() => {
            actualizarMulti();
        }, 250);
    });

    actualizarMulti();
}

// ==========================================
// 4. API DE TIPO DE CAMBIO (MONEDAS)
// ==========================================
// Las tasas reales vienen de la API (base PEN). Estos valores solo se usan si la API falla.
const API_TIPO_CAMBIO = "https://open.er-api.com/v6/latest/PEN";
let tasasCambio = {
    PEN: 1, USD: 0.27, EUR: 0.25, COP: 1100.5, MXN: 4.65, ARS: 280, CLP: 250, BRL: 1.35, BOB: 1.85,
    UYU: 10.5, PYG: 2000, VES: 9.8, CRC: 140, DOP: 15.8, GTQ: 2.1, HNL: 6.7, NIO: 9.9, PAB: 0.27,
    GBP: 0.21, CAD: 0.37, AUD: 0.41, JPY: 41.5, CNY: 1.95, CHF: 0.24
};
const SIMBOLOS_MONEDA = {
    PEN: 'S/ ', USD: '$ ', EUR: '€ ', COP: '$ ', MXN: '$ ', ARS: '$ ', CLP: '$ ', BRL: 'R$ ', BOB: 'Bs. ',
    UYU: '$U ', PYG: '₲ ', VES: 'Bs.S ', CRC: '₡ ', DOP: 'RD$ ', GTQ: 'Q ', HNL: 'L ', NIO: 'C$ ',
    PAB: 'B/. ', GBP: '£ ', CAD: 'CA$ ', AUD: 'AU$ ', JPY: '¥ ', CNY: 'CN¥ ', CHF: 'CHF '
};
let monedaActual = 'PEN'; // Soles por defecto
let tasasDesdeApi = false;

// Avisa a la página (productos, carrito) que debe volver a dibujar sus precios
function avisarCambioMoneda() {
    document.dispatchEvent(new CustomEvent('moneda-cambiada', { detail: { moneda: monedaActual } }));
}

// Cargar tasas al iniciar la página
document.addEventListener("DOMContentLoaded", async () => {
    try {
        const respuesta = await fetch(API_TIPO_CAMBIO);
        const datos = await respuesta.json();
        if (datos.result === "success" && datos.rates) {
            tasasCambio = Object.assign({}, tasasCambio, datos.rates);
            tasasDesdeApi = true;
            avisarCambioMoneda();
        }
    } catch (error) {
        // Si la API falla, el sitio sigue funcionando con las tasas de respaldo
        console.error("Error al obtener tipo de cambio:", error);
    }
});

// Función que se activa al hacer clic en los botones de moneda
function cambiarMoneda(moneda, elementoBtn) {
    if (!SIMBOLOS_MONEDA[moneda]) return;
    monedaActual = moneda;

    document.querySelectorAll('.btn-moneda').forEach(b => b.classList.remove('active'));
    const btnActivo = elementoBtn || document.getElementById(`btn${moneda}`);
    if (btnActivo) btnActivo.classList.add('active');

    const selectOtras = document.getElementById('selectOtrasMonedas');
    if (selectOtras) selectOtras.selectedIndex = 0;

    if (window.registrarEvento) registrarEvento('cambio_moneda', { moneda });
    avisarCambioMoneda();
}

// Menú desplegable "otras monedas"
function cambiarMonedaOtras(selectElement) {
    const moneda = selectElement.value;
    if (!moneda || !SIMBOLOS_MONEDA[moneda]) return;
    monedaActual = moneda;
    document.querySelectorAll('.btn-moneda').forEach(b => b.classList.remove('active'));
    if (window.registrarEvento) registrarEvento('cambio_moneda', { moneda });
    avisarCambioMoneda();
}

// Calcula y formatea el precio según la moneda activa (el cobro siempre es en soles)
function formatearPrecio(precioEnSoles) {
    const tasa = tasasCambio[monedaActual] || 1;
    return `${SIMBOLOS_MONEDA[monedaActual] || 'S/ '}${(precioEnSoles * tasa).toFixed(2)}`;
}

document.addEventListener("DOMContentLoaded", () => {
    const inputBuscar = document.getElementById("inputBuscar");
    
    if (inputBuscar) {
        // Si ya estamos en productos.php, recuperamos el texto si viene por URL
        const urlParams = new URLSearchParams(window.location.search);
        const terminoPrevio = urlParams.get("busqueda");
        if (terminoPrevio) {
            inputBuscar.value = terminoPrevio;
        }

        // Evento al presionar Enter en el buscador
        inputBuscar.addEventListener("keydown", (event) => {
            // En productos.php el filtro ya funciona en vivo (oninput), no hace falta recargar
            if (typeof filtrarProductos === "function") return;
            if (event.key === "Enter") {
                const query = inputBuscar.value.trim();
                if (query !== "") {
                    // Redirige a productos.php enviando el parámetro de búsqueda
                    window.location.href = `productos.php?busqueda=${encodeURIComponent(query)}`;
                } else {
                    window.location.href = `productos.php`;
                }
            }
        });
    }
});