// Analítica: envía eventos a api/evento.php. Equivalente a motor-analitica.js, pero guardando en MySQL.
(function () {
    const RUTA = 'api/evento.php';
    function registrarEvento(tipo, detalle) {
        try {
            const body = JSON.stringify({ tipo, detalle: detalle || {}, pagina: location.pathname.split('/').pop() || 'index' });
            if (navigator.sendBeacon) navigator.sendBeacon(RUTA, new Blob([body], { type: 'application/json' }));
            else fetch(RUTA, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body, keepalive: true });
        } catch (e) { /* la analítica nunca debe romper la página */ }
    }
    window.registrarEvento = registrarEvento;
    document.addEventListener('DOMContentLoaded', () => registrarEvento('visita'));
})();
