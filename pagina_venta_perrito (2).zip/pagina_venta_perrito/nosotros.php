<?php session_start(); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patitas Felices - Contacto</title>
    <meta name="description" content="Contacta a Patitas Felices, tienda en línea de productos para mascotas: WhatsApp, teléfono y correo.">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/style_footer.css">
    <link rel="stylesheet" href="css/style_nosotros.css">
</head>
<body>

<!-- HEADER -->
<header class="header">
    <div class="logo">
        <img src="imagenes/otras_imagenes/logo2.jpg" alt="Logo Patitas Felices">
        <span>Patitas Felices</span>
    </div>

    <div id="hamburger" class="hamburger">
        <span></span>
        <span></span>
        <span></span>
    </div>

    <?php $paginaActual = 'nosotros'; include 'includes/nav.php'; ?>
</header>

<div class="seccion-contacto">
    <h2>Contacto</h2>
    <p style="text-align:center;max-width:620px;margin:0 auto 20px">Somos una tienda 100% en línea: no tenemos local físico. Atendemos por esta web y por WhatsApp, y coordinamos el envío a tu domicilio.</p>

    <div class="info-contacto">
        <div class="info-item">
            <span>🌐</span>
            <div>
                <div>Tienda en línea (sin local físico)</div>
                <small>Dónde estamos</small>
            </div>
        </div>

        <div class="info-item">
            <span>📞</span>
            <div>
                <div><a href="tel:+51901023589">+51 901 023 589</a></div>
                <small>Teléfono</small>
            </div>
        </div>

        <div class="info-item">
            <span>💬</span>
            <div>
                <div><a href="https://wa.me/51901023589" target="_blank" rel="noopener noreferrer">Escríbenos por WhatsApp</a></div>
                <small>Horarios de atención: confírmalos por WhatsApp</small>
            </div>
        </div>

        <div class="info-item">
            <span>✉</span>
            <div>
                <div><a href="mailto:patitasfelices@gmail.com">patitasfelices@gmail.com</a></div>
                <small>Correo electrónico</small>
            </div>
        </div>
    </div>

    <div class="meta-row">
        <a href="https://wa.me/51901023589" target="_blank" rel="noopener noreferrer" class="enlace-mapa" style="background:#2E7D32;">💬 Abrir WhatsApp</a>
        <a href="productos.php" class="enlace-mapa">🛍 Ver productos</a>
    </div>
</div>

<!-- Datos estructurados (tienda en línea) -->
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "OnlineStore",
    "name": "Patitas Felices",
    "telephone": "+51 901023589",
    "email": "patitasfelices@gmail.com",
    "areaServed": "PE",
    "description": "Tienda en línea de productos para mascotas: alimento, juguetes, camas y accesorios."
}
</script>


<?php include 'includes/footer.php'; ?>

<script src="js/analitica.js"></script>
<script src="js/chatbot.js"></script>
</body>
</html>