<?php
session_start();
$logueado = !empty($_SESSION['usuario_id']);
// El catálogo se pide paginado a api/productos.php (solo llega la página que se muestra)
require_once 'conexion.php';
// Las categorías del filtro salen de la base de datos (así siempre coinciden con las reales)
try {
    $categorias_filtro = $conexion->query("SELECT id, nombre FROM categorias WHERE activo = 1 ORDER BY orden, nombre")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    $categorias_filtro = [];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Productos para mascotas - Patitas Felices</title>
    <meta name="description" content="Catálogo de Patitas Felices: comida para perros y gatos, juguetes para cachorros, camas y accesorios para mascotas con ofertas. Compra por la web o por WhatsApp.">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/style_productos.css">
    <link rel="stylesheet" href="css/style_footer.css">
</head>
<body>

<header class="header">
    <div class="logo">
        <img src="imagenes/otras_imagenes/logo2.jpg" alt="Logo Patitas Felices">
        <span>Patitas Felices</span>
    </div>

    <!-- BARRA DE BÚSQUEDA -->
    <div class="buscador-container">
        <input type="text" id="inputBuscar" placeholder="buscar..." class="input-buscar" oninput="filtrarProductos()">
    </div>

    <div id="hamburger" class="hamburger">
        <span></span>
        <span></span>
        <span></span>
    </div>
    
    <?php $paginaActual = 'productos'; include 'includes/nav.php'; ?>
</header>

<section class="productos-section">
    <h2 class="titulo-productos">Nuestros Productos</h2>

    <!-- BARRA SUPERIOR: FILTRO Y MONEDAS -->
    <div class="barra-filtros-moneda">
        <!-- SELECTOR DE CATEGORÍAS (Usamos valores genéricos en minúscula para matchear con JS) -->
        <div class="filtro-categorias">
            <select id="selectCategoria" onchange="filtrarProductos()">
                <option value="todas">Todas las categorías</option>
                <?php foreach ($categorias_filtro as $c): ?>
                    <option value="<?= (int)$c['id'] ?>"><?= htmlspecialchars(mb_convert_case($c['nombre'], MB_CASE_TITLE, 'UTF-8')) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- BOTONES Y DESPLEGABLE DE MONEDAS -->
        <div class="botones-moneda" style="display: flex; align-items: center; gap: 10px; flex-wrap:">
            <button onclick="cambiarMoneda('PEN', this)" class="btn-moneda active" id="btnPEN">Soles</button>
            <button onclick="cambiarMoneda('USD', this)" class="btn-moneda" id="btnUSD">Dólares</button>
            <button onclick="cambiarMoneda('EUR', this)" class="btn-moneda" id="btnEUR">Euros</button>
            
            <select id="selectOtrasMonedas" class="select-otras-monedas" onchange="cambiarMonedaOtras(this)" style="padding: 8px 15px; border-radius: 50px; border: 2px solid #ddd; background-color: #fff; font-size: 0.9rem; cursor: pointer; outline: none;">
                <option value="" disabled selected>otras monedas</option>
                <option value="COP">Peso Colombiano (COP)</option>
                <option value="MXN">Peso Mexicano (MXN)</option>
                <option value="ARS">Peso Argentino (ARS)</option>
                <option value="CLP">Peso Chileno (CLP)</option>
                <option value="BRL">Real Brasileño (BRL)</option>
                <option value="BOB">Boliviano (BOB)</option>
                <option value="UYU">Peso Uruguayo (UYU)</option>
                <option value="PYG">Guaraní Paraguayo (PYG)</option>
                <option value="VES">Bolívar Venezolano (VES)</option>
                <option value="CRC">Colón Costarricense (CRC)</option>
                <option value="DOP">Peso Dominicano (DOP)</option>
                <option value="GTQ">Quetzal Guatemalteco (GTQ)</option>
                <option value="HNL">Lempira Hondureño (HNL)</option>
                <option value="NIO">Córdoba Nicaragüense (NIO)</option>
                <option value="PAB">Balboa Panameño (PAB)</option>
                <option value="GBP">Libra Esterlina (GBP)</option>
                <option value="CAD">Dólar Canadiense (CAD)</option>
                <option value="AUD">Dólar Australiano (AUD)</option>
                <option value="JPY">Yen Japonés (JPY)</option>
                <option value="CNY">Yuan Chino (CNY)</option>
                <option value="CHF">Franco Suizo (CHF)</option>
            </select>
        </div>
    </div>

    <p style="text-align:center;color:#777;font-size:.85rem;margin:-6px 0 14px">Las conversiones son referenciales; el pago siempre se calcula en soles (S/).</p>

    <!-- GRID DE PRODUCTOS -->
    <div class="grid-productos" id="gridProductos">
        <!-- Los productos se cargarán dinámicamente con JavaScript -->
    </div>
</section>

<!-- FOOTER -->
<?php include 'includes/footer.php'; ?>

<script>
    const POR_PAGINA = 12;
    let paginaActual = 1;
    let totalPaginas = 1;
    let productosPagina = [];      // productos de la página que se está mostrando
    let temporizadorBusqueda;

    function esc(t) {
        return String(t ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    }

    document.addEventListener("DOMContentLoaded", () => {
        const query = new URLSearchParams(window.location.search).get("busqueda");
        const input = document.getElementById("inputBuscar");
        if (query && input) input.value = query;
        cargarCatalogo(1);
    });

    // Los precios se redibujan cuando cambia la moneda o llegan las tasas de la API
    document.addEventListener('moneda-cambiada', () => renderizarTarjetas(productosPagina));

    // Filtros: esperan 300 ms tras dejar de escribir y piden la página 1 al servidor
    function filtrarProductos() {
        clearTimeout(temporizadorBusqueda);
        temporizadorBusqueda = setTimeout(() => cargarCatalogo(1), 300);
    }

    async function cargarCatalogo(pagina) {
        const grid = document.getElementById("gridProductos");
        const categoria = document.getElementById("selectCategoria").value.toLowerCase();
        const input = document.getElementById("inputBuscar");
        const q = input ? input.value.trim() : "";

        const params = new URLSearchParams({ pagina: pagina, por_pagina: POR_PAGINA });
        if (q) params.set("q", q);
        if (categoria !== "todas") params.set("categoria", categoria);

        grid.style.opacity = "0.5";
        try {
            const r = await fetch("api/productos.php?" + params.toString());
            if (!r.ok) throw new Error("HTTP " + r.status);
            const data = await r.json();
            productosPagina = data.resultados;
            paginaActual = data.pagina;
            totalPaginas = data.totalPaginas;
            renderizarTarjetas(productosPagina);
            dibujarPaginacion();
            if (q && window.registrarEvento) registrarEvento('busqueda_catalogo', { texto: q, resultados: data.total });
        } catch (e) {
            console.error("No se pudo cargar el catálogo:", e);
            grid.innerHTML = '<p style="grid-column:1/-1;text-align:center;color:#dc2626;padding:20px">No pudimos cargar el catálogo. Intenta de nuevo en unos segundos.</p>';
        }
        grid.style.opacity = "1";
    }

    function dibujarPaginacion() {
        let nav = document.getElementById("paginacion");
        if (!nav) {
            nav = document.createElement("div");
            nav.id = "paginacion";
            nav.style.cssText = "display:flex;gap:6px;justify-content:center;flex-wrap:wrap;margin:20px 0";
            document.getElementById("gridProductos").after(nav);
        }
        nav.innerHTML = "";
        if (totalPaginas <= 1) return;

        const boton = (texto, pagina, activo, deshabilitado) => {
            const b = document.createElement("button");
            b.type = "button"; b.textContent = texto; b.disabled = !!deshabilitado;
            b.style.cssText = "padding:6px 12px;border-radius:6px;border:1px solid #ddd;cursor:" + (deshabilitado ? "default" : "pointer") +
                              ";background:" + (activo ? "#f29b2e;color:#fff" : "#fff") + (deshabilitado ? ";opacity:.5" : "");
            if (!deshabilitado) b.onclick = () => { cargarCatalogo(pagina); window.scrollTo({ top: 0, behavior: "smooth" }); };
            nav.appendChild(b);
        };
        boton("‹ Anterior", paginaActual - 1, false, paginaActual === 1);
        const desde = Math.max(1, paginaActual - 2), hasta = Math.min(totalPaginas, paginaActual + 2);
        for (let i = desde; i <= hasta; i++) boton(i, i, i === paginaActual, false);
        boton("Siguiente ›", paginaActual + 1, false, paginaActual === totalPaginas);
    }

    function renderizarTarjetas(productos) {
        const grid = document.getElementById("gridProductos");
        grid.innerHTML = "";

        if (productos.length === 0) {
            grid.innerHTML = `<p style="grid-column: 1/-1; text-align:center; color:#666; padding: 20px;">No hay productos disponibles o que coincidan con tu búsqueda.</p>`;
            return;
        }

        productos.forEach(p => {
            const rutaImagen = p.imagen ? `imagenes/productos/${p.imagen}` : `imagenes/otras_imagenes/logo2.jpg`;
            const precio = parseFloat(p.precio);
            const enOferta = Number(p.en_oferta) === 1 && parseFloat(p.precio_normal) > precio;
            const stock = parseInt(p.stock, 10);

            const card = document.createElement("div");
            card.className = "card-producto";
            card.innerHTML = `
                <img src="${esc(rutaImagen)}" alt="${esc(p.nombre)}" loading="lazy">
                <h3>${esc(p.nombre)}</h3>
                <p class="precio">${enOferta ? `<s style="color:#999;font-size:.85em">${formatearPrecio(parseFloat(p.precio_normal))}</s> ` : ''}${formatearPrecio(precio)}</p>
                ${enOferta ? '<p style="color:#e11d48;font-weight:bold;margin:0">¡Oferta!</p>' : ''}
                <p class="descripcion">${esc(p.descripcion)}</p>
                ${stock > 0
                    ? `<button type="button" class="btn-carrito" data-id="${Number(p.producto_id)}" aria-label="Agregar al carrito">🛒</button>`
                    : '<span style="color:#dc2626;font-weight:bold">Agotado</span>'}
            `;
            const btn = card.querySelector('.btn-carrito');
            if (btn) btn.addEventListener('click', () => agregarAlCarrito(Number(p.producto_id), p.nombre, precio, rutaImagen));
            grid.appendChild(card);
        });
    }

    const USUARIO_LOGUEADO = <?php echo $logueado ? 'true' : 'false'; ?>;

    function agregarAlCarrito(id, nombre, precio, imagen) {
        // Comprar requiere cuenta: si no hay sesión, se manda al login y luego se vuelve a Productos
        if (!USUARIO_LOGUEADO) {
            alert("Debes iniciar sesión para comprar.");
            window.location.href = "login.php?volver=productos.php";
            return;
        }
        let carrito = JSON.parse(localStorage.getItem('carrito')) || [];
        
        let existente = carrito.find(item => item.id === id);
        if (existente) {
            existente.cantidad += 1;
        } else {
            carrito.push({
                id: id,
                nombre: nombre,
                precio: precio,
                imagen: imagen,
                cantidad: 1
            });
        }

        localStorage.setItem('carrito', JSON.stringify(carrito));
        mostrarMensaje("Producto agregado 🐾");
        if (window.registrarEvento) registrarEvento('agregar_carrito', { producto: nombre, id: id });
    }

    function mostrarMensaje(texto) {
        const aviso = document.createElement("div");
        aviso.className = "mensaje-carrito";
        aviso.innerText = texto;
        aviso.style.cssText = "position: fixed; bottom: 20px; right: 20px; background: #333; color: #fff; padding: 12px 20px; border-radius: 8px; z-index: 1000; box-shadow: 0 4px 6px rgba(0,0,0,0.1);";

        document.body.appendChild(aviso);
        setTimeout(() => aviso.remove(), 2000);
    }
</script>
<script src="js/script.js"></script>
<script src="js/analitica.js"></script>
<script src="js/chatbot.js"></script>

</body>
</html>