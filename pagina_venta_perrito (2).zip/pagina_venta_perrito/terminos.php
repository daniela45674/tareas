<?php session_start(); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Términos de Servicio - Patitas Felices</title>
    <meta name="description" content="Condiciones de uso de Patitas Felices: cuenta, precios, pagos simulados y limitación de responsabilidad.">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/style_footer.css">
    <link rel="stylesheet" href="css/style_legal.css">
</head>
<body>
<header class="header">
    <div class="logo">
        <img src="imagenes/otras_imagenes/logo2.jpg" alt="Logo Patitas Felices">
        <span>Patitas Felices</span>
    </div>
    <div id="hamburger" class="hamburger"><span></span><span></span><span></span></div>
    <?php $paginaActual = "legal"; include "includes/nav.php"; ?>
</header>

<main class="legal">
    <h1>Términos de Servicio</h1>
    <p class="fecha">Última actualización: <?= date('d/m/Y') ?></p>

    <div class="aviso"><strong>El pago es una simulación educativa.</strong> No se cobra dinero real ni se entregan productos. Patitas Felices es un proyecto académico, no un negocio real.</div>

    <h2>1. Uso del sitio</h2>
    <p>Puedes navegar el catálogo sin registrarte. Para comprar necesitas crear una cuenta con datos veraces y mantener tu contraseña en reserva.</p>

    <h2>2. Precios y stock</h2>
    <ul>
        <li>Los precios están en soles (S/). El total de cada pedido se <strong>recalcula siempre en el servidor</strong> con los precios vigentes.</li>
        <li>La conversión a dólares, euros u otras monedas es <strong>solo referencial</strong> (tipo de cambio de un servicio externo); el cobro siempre se calcula en soles.</li>
        <li>El stock mostrado puede cambiar; si un producto se agota antes de pagar, el pedido no se completa.</li>
    </ul>

    <h2>3. Pagos</h2>
    <p>El pago con tarjeta usa una pasarela de pruebas (sandbox). Usa solo las tarjetas de prueba indicadas en el checkout; <strong>no ingreses tarjetas reales</strong>. También puedes coordinar tu pedido por WhatsApp.</p>

    <h2>4. Asistente virtual</h2>
    <p>El asistente responde por coincidencia de palabras clave y puede no saber todo. Cuando no encuentra respuesta, te deriva a WhatsApp. Sus respuestas son orientativas.</p>

    <h2>5. Envíos</h2>
    <p>No hay envíos reales en este proyecto. En un negocio real, el plazo y costo se coordinarían con el cliente al confirmar el pedido.</p>

    <h2>6. Limitación de responsabilidad</h2>
    <p>Al tratarse de un proyecto académico, el sitio se ofrece «tal cual», sin garantías de disponibilidad, y sus responsables no responden por pérdidas derivadas de su uso.</p>

    <h2>7. Datos personales</h2>
    <p>El tratamiento de tus datos se describe en la <a href="privacidad.php">Política de Privacidad</a>.</p>

    <h2>8. Contacto</h2>
    <p><a href="mailto:patitasfelices@gmail.com">patitasfelices@gmail.com</a> · WhatsApp <a href="https://wa.me/51901023589">901 023 589</a>.</p>
</main>

<?php include "includes/footer.php"; ?>
<script src="js/script.js"></script>
</body>
</html>