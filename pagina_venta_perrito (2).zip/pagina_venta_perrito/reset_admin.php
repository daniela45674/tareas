<?php
// SCRIPT TEMPORAL: restablece la contraseña del administrador (usuario id=1).
// Solo funciona desde tu propia PC (localhost) y se borra solo al terminar.
if (!in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'], true)) { http_response_code(403); exit('Solo desde localhost.'); }
include 'conexion.php';
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nueva = $_POST['password'] ?? '';
    if (strlen($nueva) < 6) {
        $msg = 'La contraseña debe tener al menos 6 caracteres.';
    } else {
        $st = $conexion->prepare("UPDATE usuarios SET password = ?, rol = 'admin', estado = 'activo' WHERE id = 1");
        $st->execute([password_hash($nueva, PASSWORD_DEFAULT)]);
        $email = $conexion->query("SELECT email FROM usuarios WHERE id = 1")->fetchColumn();
        @unlink(__FILE__);
        exit("<p>Listo. Ya puedes entrar en <a href='login.php'>login.php</a> con <b>" . htmlspecialchars($email) . "</b> y la contraseña que acabas de escribir.<br>Este archivo se eliminó solo.</p>");
    }
}
?>
<!DOCTYPE html><html lang="es"><meta charset="UTF-8"><title>Restablecer admin</title>
<body style="font-family:Arial;max-width:420px;margin:60px auto">
<h2>Nueva contraseña de administrador</h2>
<?php if ($msg) echo "<p style='color:red'>$msg</p>"; ?>
<form method="POST"><input type="text" name="password" placeholder="Nueva contraseña" style="width:100%;padding:8px" required>
<button style="margin-top:10px;padding:8px 16px">Guardar</button></form></body></html>
