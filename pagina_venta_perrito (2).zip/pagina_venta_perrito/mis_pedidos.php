<?php
session_start();
require_once 'conexion.php';
if (empty($_SESSION['usuario_id'])) { header('Location: login.php'); exit(); }

$st = $conexion->prepare("SELECT * FROM pedidos WHERE usuario_id = ? ORDER BY fecha_pedido DESC");
$st->execute([$_SESSION['usuario_id']]);
$pedidos = $st->fetchAll(PDO::FETCH_ASSOC);
$det = $conexion->prepare("SELECT dp.cantidad, dp.precio_unitario, p.nombre FROM detalle_pedidos dp JOIN productos p ON p.id = dp.producto_id WHERE dp.pedido_id = ?");
?>
<!DOCTYPE html>
<html lang="es"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Mis pedidos - Patitas Felices</title>
<link rel="stylesheet" href="css/style.css">
<style>
 .wrap{max-width:900px;color:#d0250d;margin:30px auto;padding:0 16px}
 .pedido{background:#fbe1c6;border:1px solid #5b3207;color:#da5903;border-radius:10px;padding:16px;margin-bottom:16px;box-shadow:0 2px 6px rgba(71, 8, 8, 0.10)}
 .badge{display:inline-block;padding:2px 10px;border-radius:12px;font-size:12px;color:#ffffff;margin-left:6px}
 .pagado{background:#67ce00}.pendiente{background:#ffffff}.cancelado{background:#dc2626}
 .procesando{background:#e6991a}.enviado{background:#2563eb}.entregado{background:#16a34a}
</style></head><body>
<div class="wrap">
  <a href="home.php">⬅ Inicio</a>
  <h2>Mis pedidos</h2>
  <?php if (!$pedidos): ?><p>Aún no tienes pedidos 🐾</p><?php endif; ?>
  <?php foreach ($pedidos as $p): $det->execute([$p['id']]); ?>
    <div class="pedido">
      <strong>Pedido #<?= (int)$p['id'] ?></strong> — <?= htmlspecialchars($p['fecha_pedido']) ?>
      <span class="badge <?= $p['estado'] ?>"><?= htmlspecialchars($p['estado']) ?></span>
      <?php if ($p['estado'] === 'pagado'): ?><span class="badge <?= strtolower($p['estado_envio']) ?>"><?= htmlspecialchars($p['estado_envio']) ?></span><?php endif; ?>
      <ul>
        <?php foreach ($det->fetchAll(PDO::FETCH_ASSOC) as $d): ?>
          <li><?= htmlspecialchars($d['nombre']) ?> × <?= (int)$d['cantidad'] ?> — S/ <?= number_format($d['precio_unitario'], 2) ?></li>
        <?php endforeach; ?>
      </ul>
      <strong>Total: S/ <?= number_format($p['total'], 2) ?></strong>
    </div>
  <?php endforeach; ?>
<p style="text-align:center;font-size:.85rem;margin-top:14px"><a href="privacidad.php">Política de Privacidad</a> · <a href="terminos.php">Términos de Servicio</a></p></div></body></html>
