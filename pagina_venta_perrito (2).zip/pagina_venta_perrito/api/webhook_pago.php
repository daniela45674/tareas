<?php
/**
 * Endpoint de webhook: así es como una pasarela REAL (Stripe, Culqi, Mercado Pago) avisaría a tu servidor.
 * Probar con curl:
 *   curl -X POST http://localhost/pagina_venta_perrito/api/webhook_pago.php \
 *        -H "Content-Type: application/json" -H "X-Webhook-Secret: TU_SECRETO" \
 *        -d '{"evento":"pago.aprobado","pedido_id":12,"referencia":"sim_abc123"}'
 * Eventos: pago.aprobado | pago.rechazado
 */
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/pedidos.php';
require_once __DIR__ . '/../includes/analitica.php';

function fin(int $code, array $d) { http_response_code($code); echo json_encode($d, JSON_UNESCAPED_UNICODE); exit; }

if ($_SERVER['REQUEST_METHOD'] !== 'POST') fin(405, ['error' => 'Usa POST']);
if (WEBHOOK_SECRET === 'cambia-esto-por-un-secreto-largo') fin(503, ['error' => 'Configura WEBHOOK_SECRET en includes/config.php']);
if (!hash_equals(WEBHOOK_SECRET, $_SERVER['HTTP_X_WEBHOOK_SECRET'] ?? '')) fin(401, ['error' => 'Firma inválida']);

$in = json_decode(file_get_contents('php://input'), true) ?? [];
$evento = $in['evento'] ?? ''; $pedidoId = (int)($in['pedido_id'] ?? 0);
if ($pedidoId <= 0) fin(422, ['error' => 'pedido_id requerido']);

try {
    $conexion->beginTransaction();
    if ($evento === 'pago.aprobado') {
        $r = marcarPedidoComoPagado($conexion, $pedidoId, ['referencia' => $in['referencia'] ?? null, 'proveedor' => $in['proveedor'] ?? 'webhook']);
    } elseif ($evento === 'pago.rechazado') {
        $conexion->prepare("UPDATE pagos SET estado='rechazado', mensaje=? WHERE pedido_id=?")->execute([substr($in['motivo'] ?? 'Rechazado', 0, 150), $pedidoId]);
        $conexion->prepare("UPDATE pedidos SET estado='cancelado' WHERE id=? AND estado='pendiente'")->execute([$pedidoId]);
        $r = ['pedido_id' => $pedidoId, 'cancelado' => true];
    } else {
        $conexion->rollBack(); fin(422, ['error' => 'evento desconocido']);
    }
    $conexion->commit();
    registrarEvento($conexion, $evento === 'pago.aprobado' ? 'pago_exitoso' : 'pago_rechazado', ['pedido_id' => $pedidoId, 'via' => 'webhook']);
    fin(200, ['ok' => true] + $r);
} catch (RuntimeException $e) {
    if ($conexion->inTransaction()) $conexion->rollBack();
    fin(409, ['ok' => false, 'error' => $e->getMessage()]);
} catch (Throwable $e) {
    if ($conexion->inTransaction()) $conexion->rollBack();
    error_log($e->getMessage());
    fin(500, ['ok' => false, 'error' => 'Error interno']);
}
