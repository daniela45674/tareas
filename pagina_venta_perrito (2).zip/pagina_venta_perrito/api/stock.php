<?php
// GET api/stock.php?ids=1,5,7  -> stock actual  {"1":10,"5":0}
// GET api/stock.php?bajo=1     -> productos con stock <= stock_minimo (solo admin)
header('Content-Type: application/json; charset=utf-8');
session_start();
require_once __DIR__ . '/../conexion.php';

if (isset($_GET['bajo'])) {
    if (($_SESSION['rol'] ?? '') !== 'admin') { http_response_code(403); echo json_encode(['error' => 'No autorizado']); exit; }
    $rows = $conexion->query("SELECT id, nombre, stock, stock_minimo FROM productos WHERE activo = 1 AND stock <= stock_minimo ORDER BY stock ASC")->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($rows, JSON_UNESCAPED_UNICODE); exit;
}

$ids = array_values(array_filter(array_map('intval', explode(',', $_GET['ids'] ?? ''))));
if (!$ids) { echo json_encode((object)[]); exit; }
$in = implode(',', array_fill(0, count($ids), '?'));
$st = $conexion->prepare("SELECT id, stock FROM productos WHERE activo = 1 AND id IN ($in)");
$st->execute($ids);
echo json_encode($st->fetchAll(PDO::FETCH_KEY_PAIR));
