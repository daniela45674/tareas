<?php
// api/productos.php
header('Content-Type: application/json; charset=utf-8');

try {
    // Incluimos la conexión (subiendo un nivel desde la carpeta api/)
    require_once '../conexion.php';

    // Parámetros de paginación y filtros enviados por GET desde el catálogo
    $pagina = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
    $porPagina = isset($_GET['por_pagina']) ? (int)$_GET['por_pagina'] : 12;
    if ($pagina < 1) $pagina = 1;
    if ($porPagina < 1) $porPagina = 12;
    $offset = ($pagina - 1) * $porPagina;

    $busqueda = isset($_GET['q']) ? trim($_GET['q']) : '';
    $categoria = isset($_GET['categoria']) ? trim($_GET['categoria']) : 'todas';

    // Construcción de la consulta dinámica
    $where = ["activo = 1"]; // solo productos no eliminados
    $params = [];

    if ($busqueda !== '') {
        $where[] = "(nombre LIKE ? OR descripcion LIKE ?)";
        $params[] = "%$busqueda%";
        $params[] = "%$busqueda%";
    }

    if ($categoria !== 'todas' && is_numeric($categoria)) {
        $where[] = "categoria_id = ?";
        $params[] = (int)$categoria;
    }

    $whereString = implode(" AND ", $where);

    // Contar el total de registros filtrados
    $sqlTotal = "SELECT COUNT(*) FROM productos WHERE $whereString";
    $stmtTotal = $conexion->prepare($sqlTotal);
    $stmtTotal->execute($params);
    $totalRegistros = $stmtTotal->fetchColumn();
    $totalPaginas = max(1, ceil($totalRegistros / $porPagina));

    // Obtener los productos de la página actual
    $sqlProductos = "SELECT id AS producto_id, nombre, descripcion,
                            IF(en_oferta = 1 AND precio_oferta IS NOT NULL, precio_oferta, precio) AS precio,
                            precio AS precio_normal, en_oferta, stock, imagen, categoria_id 
                     FROM productos 
                     WHERE $whereString 
                     ORDER BY id DESC 
                     LIMIT $porPagina OFFSET $offset";
    
    $stmt = $conexion->prepare($sqlProductos);
    $stmt->execute($params);
    $productos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Devolver la respuesta en formato JSON limpio para JavaScript
    echo json_encode([
        'resultados' => $productos,
        'pagina' => $pagina,
        'totalPaginas' => $totalPaginas,
        'total' => $totalRegistros
    ], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'error' => true,
        'mensaje' => 'Error en el servidor: ' . $e->getMessage(),
        'resultados' => [],
        'pagina' => 1,
        'totalPaginas' => 1
    ], JSON_UNESCAPED_UNICODE);
}
?>