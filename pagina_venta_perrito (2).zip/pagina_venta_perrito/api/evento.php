<?php
// Recibe eventos del navegador (js/analitica.js). Solo acepta una lista blanca de tipos.
header('Content-Type: application/json; charset=utf-8');
session_start();
require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/../includes/analitica.php';

$permitidos = ['visita', 'agregar_carrito', 'clic_whatsapp', 'busqueda_catalogo', 'cambio_moneda'];
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo '{}'; exit; }
$in = json_decode(file_get_contents('php://input'), true) ?? [];
$tipo = $in['tipo'] ?? '';
if (!in_array($tipo, $permitidos, true)) { http_response_code(422); echo json_encode(['error' => 'tipo no permitido']); exit; }
$detalle = is_array($in['detalle'] ?? null) ? $in['detalle'] : [];
if (strlen(json_encode($detalle)) > 500) $detalle = [];
registrarEvento($conexion, $tipo, $detalle, (string)($in['pagina'] ?? ''));
echo json_encode(['ok' => true]);
