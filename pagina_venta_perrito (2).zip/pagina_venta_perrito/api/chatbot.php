<?php
/**
 * Asistente virtual (equivalente a motor-chatbot.js): coincidencia de palabras clave sobre
 * una base de conocimiento (FAQ) + el catálogo REAL de la base de datos. Sin APIs de pago.
 * Cada pregunta se registra como evento 'chatbot_pregunta' para medir la tasa de resolución.
 * >>> Edita BASE_CONOCIMIENTO con los datos reales de tu tienda (horarios, pagos, envíos). <<<
 */
header('Content-Type: application/json; charset=utf-8');
session_start();
require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/../includes/analitica.php';

const WHATSAPP = '51901023589';

const PALABRAS_VACIAS = ['el','la','los','las','un','una','unos','unas','de','del','al','y','o','a','en','es','son','que','cual','cuales',
    'como','para','por','con','se','su','sus','mi','tu','me','te','lo','le','hay','tiene','tienen','puedo','quiero','necesito','hola','buenas'];

$BASE_CONOCIMIENTO = [
    ['id' => 'horario',   'claves' => ['horario','horarios','atienden','atencion','hora','abren','cierran'],
     'respuesta' => 'Para confirmar nuestros horarios de atención escríbenos por WhatsApp al +51 901 023 589 y te respondemos a la brevedad.'],
    ['id' => 'ubicacion', 'claves' => ['ubicacion','direccion','donde','local','tienda','queda','ubicados'],
     'respuesta' => 'Somos una tienda en línea y no tenemos local físico: atendemos por esta web y por WhatsApp, y coordinamos el envío a tu domicilio.'],
    ['id' => 'pago',      'claves' => ['pago','pagar','tarjeta','yape','plin','transferencia','factura','boleta'],
     'respuesta' => 'Puedes pagar con tarjeta desde tu carrito (modo prueba por ahora) o coordinar tu pedido por WhatsApp.'],
    ['id' => 'entrega',   'claves' => ['entrega','envio','envios','demora','tiempo','plazo','delivery','despacho','provincia'],
     'respuesta' => 'Enviamos a la dirección registrada en tu cuenta. El plazo exacto lo coordinamos contigo por WhatsApp al confirmar el pedido.'],
    ['id' => 'ofertas',   'claves' => ['oferta','ofertas','promocion','promociones','descuento','rebaja','barato'], 'respuesta' => ''],
    ['id' => 'cuenta',    'claves' => ['cuenta','registrar','registro','login','sesion','contrasena','password'],
     'respuesta' => 'Para comprar necesitas una cuenta: usa "Regístrate" en la página de inicio de sesión y luego ingresa con tu correo.'],
    ['id' => 'cotizar',   'claves' => ['cotizar','cotizacion','presupuesto','precio','precios','comprar','consultar'],
     'respuesta' => 'Agrega los productos al carrito y paga con tarjeta, o envíanos tu pedido por WhatsApp desde el carrito.'],
];

function normalizar(string $t): array
{
    $t = mb_strtolower($t, 'UTF-8');
    $t = strtr($t, ['á'=>'a','é'=>'e','í'=>'i','ó'=>'o','ú'=>'u','ü'=>'u','ñ'=>'n']);
    $t = preg_replace('/[^a-z0-9\s]/', ' ', $t);
    $palabras = preg_split('/\s+/', trim($t), -1, PREG_SPLIT_NO_EMPTY);
    return array_values(array_filter($palabras, fn($p) => strlen($p) > 2 && !in_array($p, PALABRAS_VACIAS, true)));
}
function coincidencias(array $usuario, array $claves): int { return count(array_intersect($claves, $usuario)); }

$in = json_decode(file_get_contents('php://input'), true) ?? [];
$texto = trim(mb_substr((string)($in['mensaje'] ?? ''), 0, 300));
if ($texto === '') { echo json_encode(['tipo' => 'vacio', 'respuesta' => 'Escribe tu pregunta 🐾']); exit; }
$palabras = normalizar($texto);

// 1) Mejor FAQ
$mejorFaq = null; $ptsFaq = 0;
foreach ($BASE_CONOCIMIENTO as $e) {
    $pts = coincidencias($palabras, $e['claves']);
    if ($pts > $ptsFaq) { $ptsFaq = $pts; $mejorFaq = $e; }
}

// 2) Mejor producto del catálogo real
$mejorProd = null; $ptsProd = 0;
$rows = $conexion->query(
    "SELECT p.nombre, p.marca, p.stock, c.nombre AS categoria,
            IF(p.en_oferta = 1 AND p.precio_oferta IS NOT NULL, p.precio_oferta, p.precio) AS precio
     FROM productos p LEFT JOIN categorias c ON c.id = p.categoria_id WHERE p.activo = 1")->fetchAll(PDO::FETCH_ASSOC);
foreach ($rows as $r) {
    $pts = coincidencias($palabras, normalizar($r['nombre'] . ' ' . ($r['categoria'] ?? '') . ' ' . ($r['marca'] ?? '')));
    if ($pts > $ptsProd) { $ptsProd = $pts; $mejorProd = $r; }
}

if ($ptsProd > 0 && $ptsProd >= $ptsFaq) {
    $disp = (int)$mejorProd['stock'] > 0 ? 'Disponible (' . (int)$mejorProd['stock'] . ' en stock).' : 'Por ahora está agotado.';
    $res = ['tipo' => 'producto', 'respuesta' => sprintf('Tenemos "%s"%s a S/ %s. %s Puedes verlo en la sección Productos.',
        $mejorProd['nombre'], $mejorProd['categoria'] ? ' en ' . $mejorProd['categoria'] : '', number_format((float)$mejorProd['precio'], 2), $disp)];
} elseif ($mejorFaq && $mejorFaq['id'] === 'ofertas') {
    $of = $conexion->query("SELECT nombre, precio_oferta FROM productos WHERE activo = 1 AND en_oferta = 1 AND precio_oferta IS NOT NULL ORDER BY id DESC LIMIT 3")->fetchAll(PDO::FETCH_ASSOC);
    $lista = implode(' · ', array_map(fn($o) => $o['nombre'] . ' S/ ' . number_format((float)$o['precio_oferta'], 2), $of));
    $res = ['tipo' => 'faq', 'respuesta' => $lista ? "Ofertas actuales: $lista. Más en la página de inicio." : 'Por ahora no tenemos ofertas activas, ¡vuelve pronto!'];
} elseif ($mejorFaq) {
    $res = ['tipo' => 'faq', 'respuesta' => $mejorFaq['respuesta']];
} else {
    $res = ['tipo' => 'sin_respuesta', 'respuesta' => 'No encontré una respuesta exacta. Escríbenos por WhatsApp y un asesor te ayuda: https://wa.me/' . WHATSAPP];
}

registrarEvento($conexion, 'chatbot_pregunta', ['texto' => mb_substr($texto, 0, 120), 'tipoRespuesta' => $res['tipo']], 'chatbot');
echo json_encode($res, JSON_UNESCAPED_UNICODE);
