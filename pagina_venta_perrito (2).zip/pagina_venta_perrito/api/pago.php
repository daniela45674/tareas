<?php
// Endpoint HTTP de la pasarela simulada (para probar con Postman/curl).
// POST JSON: {"monto":50.5,"moneda":"PEN","tarjeta":"4242424242424242","vencimiento":"12/30","cvv":"123"}
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../includes/pago_simulado.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['error' => 'Usa POST']); exit; }
$in = json_decode(file_get_contents('php://input'), true) ?? [];
$r = simularPago((float)($in['monto'] ?? 0), $in['moneda'] ?? 'PEN', (string)($in['tarjeta'] ?? ''), (string)($in['vencimiento'] ?? ''), (string)($in['cvv'] ?? ''));
http_response_code($r['estado'] === 'aprobado' ? 200 : 402);
echo json_encode($r, JSON_UNESCAPED_UNICODE);
