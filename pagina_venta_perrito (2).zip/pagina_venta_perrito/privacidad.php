<?php session_start(); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Política de Privacidad - Patitas Felices</title>
    <meta name="description" content="Qué datos recopila Patitas Felices, para qué los usa y dónde se guardan.">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/style_footer.css">
    <link rel="stylesheet" href="css/style_legal.css">
</head>
<body>
<header class="header">
    <div class="logo">
        <img src="imagenes/otras_imagenes/logo2.jpg" alt="Logo Patitas Felices">
        <span>Patitas Felices</span>
    </div>
    <div id="hamburger" class="hamburger"><span></span><span></span><span></span></div>
    <?php $paginaActual = "legal"; include "includes/nav.php"; ?>
</header>

<main class="legal">
    <h1>Política de Privacidad</h1>
    <p class="fecha">Última actualización: <?= date('d/m/Y') ?></p>

    <div class="aviso">Patitas Felices es un <strong>proyecto académico</strong> de práctica (curso de E-business). No es un negocio real: los datos se guardan en una base de datos de prueba.</div>

    <h2>1. Qué datos recopilamos</h2>
    <ul>
        <li><strong>Cuenta:</strong> nombre, correo electrónico, teléfono, dirección y contraseña. La contraseña se guarda con hash (<code>password_hash</code>), nunca en texto plano.</li>
        <li><strong>Pedidos y pagos de prueba:</strong> productos, cantidades, total y estado. De la tarjeta de prueba solo se guardan los <strong>últimos 4 dígitos</strong> y una referencia de transacción; nunca el número completo ni el CVV.</li>
        <li><strong>Navegación:</strong> eventos como visitas, búsquedas, productos agregados al carrito, clics a WhatsApp y preguntas al asistente virtual, usados para medir el funcionamiento del sitio.</li>
    </ul>

    <h2>2. Dónde se guardan</h2>
    <p>En una base de datos MySQL de práctica. El carrito se guarda en el <em>localStorage</em> de tu navegador y no se envía al servidor hasta que pagas.</p>

    <h2>3. Para qué los usamos</h2>
    <ul>
        <li>Crear y gestionar tu cuenta y tus pedidos.</li>
        <li>Mostrarte el historial en «Mis pedidos» y coordinar el envío.</li>
        <li>Medir visitas y conversión para mejorar el sitio (sin vender ni compartir datos con terceros).</li>
    </ul>

    <h2>4. Cookies y servicios externos</h2>
    <ul>
        <li><strong>Cookie de sesión:</strong> necesaria para mantener tu sesión iniciada. No usamos cookies publicitarias.</li>
        <li><strong>Tipo de cambio:</strong> el sitio consulta el servicio externo open.er-api.com para mostrar precios referenciales en otras monedas. Esa consulta se hace desde tu navegador.</li>
        <li><strong>WhatsApp:</strong> si eliges comprar por WhatsApp, el mensaje con tu pedido se envía por esa aplicación y se rige por sus propias políticas.</li>
    </ul>

    <h2>5. Tus derechos</h2>
    <p>Conforme a la Ley N.° 29733, Ley de Protección de Datos Personales (Perú), puedes solicitar acceso, rectificación, cancelación u oposición sobre tus datos escribiendo a <a href="mailto:patitasfelices@gmail.com">patitasfelices@gmail.com</a> o por WhatsApp al <a href="https://wa.me/51901023589">901 023 589</a>.</p>

    <h2>6. Seguridad</h2>
    <p>Usamos contraseñas con hash, consultas preparadas contra inyección SQL y validación de precios y stock en el servidor. Ningún sistema es 100 % seguro: por eso <strong>no debes usar tarjetas reales</strong> en este sitio de prueba.</p>
</main>

<?php include "includes/footer.php"; ?>
<script src="js/script.js"></script>
</body>
</html>