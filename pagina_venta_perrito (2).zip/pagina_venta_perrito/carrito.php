<?php
session_start();
$logueado = !empty($_SESSION['usuario_id']);
// El carrito y la compra solo existen con sesión iniciada
if (!$logueado) {
    header('Location: login.php?volver=carrito.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patitas Felices - Carrito</title>
    <meta name="robots" content="noindex">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/style_carrito.css">
    <link rel="stylesheet" href="css/style_footer.css">
</head>
<body>

<header class="header">
    <div class="logo">
        <img src="imagenes/otras_imagenes/logo2.jpg" alt="Logo Patitas Felices">
        <span>Patitas Felices</span>
    </div>

    <div id="hamburger" class="hamburger">
        <span></span>
        <span></span>
        <span></span>
    </div>

    <?php $paginaActual = 'carrito'; include 'includes/nav.php'; ?>
</header>

<section class="carrito-section">
    <h2 class="titulo-carrito">Tu Carrito</h2>

    <!-- Botones de Moneda para sincronizar la conversión en el carrito -->
    <div class="botones-moneda" style="margin-bottom: 25px;">
        <button onclick="cambiarMoneda('USD')" class="btn-moneda" id="btnUSD">dólares</button>
        <button onclick="cambiarMoneda('EUR')" class="btn-moneda" id="btnEUR">euros</button>
        <button onclick="cambiarMoneda('PEN')" class="btn-moneda active" id="btnPEN">soles</button>
    </div>

    <?php if (!$logueado): ?>
    <div style="background:#fff7ed;border:1px solid #fdba74;color:#9a3412;padding:12px 16px;border-radius:8px;margin-bottom:20px;text-align:center">
        Para comprar necesitas iniciar sesión.
        <a href="login.php?volver=carrito.php" style="font-weight:bold">Iniciar sesión</a> ·
        <a href="registro.php" style="font-weight:bold">Crear cuenta</a>
    </div>
    <?php endif; ?>

    <div class="lista-carrito" id="listaCarrito">
        <!-- Los ítems se cargan dinámicamente aquí -->
    </div>

    <p style="text-align:center;color:#777;font-size:.85rem">Las conversiones son referenciales; el pago con tarjeta se cobra siempre en soles (S/).</p>

    <div class="total-carrito">
        <h2>Total general:  
            <span id="totalGeneral">S/ 0.00</span>
        </h2>
    </div>

    <div class="comprar-ahora-box">
        <button onclick="abrirPago()" class="btn-comprar-ahora" style="border:none;cursor:pointer;margin-right:10px;">Pagar con tarjeta 💳</button>
        <button onclick="enviarPedidoWhatsApp()" class="btn-comprar-ahora" style="border: none; cursor: pointer;">Comprar por WhatsApp 🛒📱</button>
    </div>
</section>

<?php include 'includes/footer.php'; ?>

<script src="js/script.js"></script>

<script>
// Cargar y renderizar el carrito al abrir la página
document.addEventListener("DOMContentLoaded", () => {
    setTimeout(cargarCarrito, 200);
});

function esc(t) { return String(t ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

function cargarCarrito() {
    const listaCarrito = document.getElementById("listaCarrito");
    const totalGeneralEl = document.getElementById("totalGeneral");
    
    let carrito = JSON.parse(localStorage.getItem('carrito')) || [];
    
    listaCarrito.innerHTML = "";
    let precioTotalSoles = 0;

    if (carrito.length === 0) {
        listaCarrito.innerHTML = `<p style="text-align:center; padding: 30px; color: #666; font-size: 18px;">Tu carrito está vacío 🐾</p>`;
        totalGeneralEl.innerText = formatearPrecio(0);
        return;
    }

    carrito.forEach((item, index) => {
        let subtotalSoles = item.precio * item.cantidad;
        precioTotalSoles += subtotalSoles;

        let itemDiv = document.createElement("div");
        itemDiv.className = "item-carrito";
        itemDiv.innerHTML = `
            <img src="${item.imagen}" alt="producto">
            <div class="info-carrito">
                <h3>${esc(item.nombre)}</h3>
                <p class="precio-unit">Precio: <strong>${formatearPrecio(item.precio)}</strong></p>
                
                <div class="botones-carrito">
                    <button type="button" class="btn-cantidad" onclick="cambiarCantidad(${index}, 1)">+</button>
                    <input disabled class="cantidad-box" value="${item.cantidad}">
                    <button type="button" class="btn-cantidad" onclick="cambiarCantidad(${index}, -1)">-</button>
                </div>

                <p class="subtotal">Subtotal: <strong>${formatearPrecio(subtotalSoles)}</strong></p>
            </div>
            <button type="button" class="btn-eliminar" onclick="eliminarItem(${index})">✖</button>
        `;
        listaCarrito.appendChild(itemDiv);
    });

    totalGeneralEl.innerText = formatearPrecio(precioTotalSoles);
}

// Al cambiar la moneda (o llegar las tasas de la API) se vuelven a dibujar los precios
document.addEventListener('moneda-cambiada', cargarCarrito);

// Sumar o restar cantidades
function cambiarCantidad(index, cambio) {
    let carrito = JSON.parse(localStorage.getItem('carrito')) || [];
    
    carrito[index].cantidad += cambio;
    
    if (carrito[index].cantidad <= 0) {
        carrito.splice(index, 1);
    }

    localStorage.setItem('carrito', JSON.stringify(carrito));
    cargarCarrito();
}

// Eliminar un producto individual
function eliminarItem(index) {
    let carrito = JSON.parse(localStorage.getItem('carrito')) || [];
    carrito.splice(index, 1);
    localStorage.setItem('carrito', JSON.stringify(carrito));
    
    let aviso = document.createElement("div");
    aviso.className = "mensaje-eliminado";
    aviso.innerText = "Producto eliminado 🗑️";
    document.body.appendChild(aviso);
    setTimeout(() => { aviso.remove(); }, 1600);

    cargarCarrito();
}

// Enviar pedido múltiple a WhatsApp con la moneda activa seleccionada
function enviarPedidoWhatsApp() {
    if (!exigirSesion()) return;
    let carrito = JSON.parse(localStorage.getItem('carrito')) || [];
    if (carrito.length === 0) {
        alert("Tu carrito está vacío. ¡Agrega productos antes de pedir!");
        return;
    }

    if (window.registrarEvento) registrarEvento('clic_whatsapp', { items: carrito.length, productos: carrito.map(i => i.nombre).join(', ').slice(0, 200) });
    let mensaje = "¡Hola, Patitas Felices! 🐾 Deseo realizar el siguiente pedido:\n\n";
    let precioTotalSoles = 0;

    carrito.forEach((item, index) => {
        let subtotalSoles = item.precio * item.cantidad;
        precioTotalSoles += subtotalSoles;

        mensaje += `*${index + 1}. ${item.nombre}*\n`;
        mensaje += `   Cantidad: ${item.cantidad}\n`;
        mensaje += `   Precio unitario: ${formatearPrecio(item.precio)}\n`;
        mensaje += `   Subtotal: ${formatearPrecio(subtotalSoles)}\n\n`;
    });

    mensaje += `\n`;
    mensaje += `*Total a pagar: ${formatearPrecio(precioTotalSoles)}*\n\n`;
    mensaje += "Quedo a la espera de la confirmación. ¡Gracias!";

    let numeroWhatsApp = "51901023589"; 
    let url = `https://wa.me/${numeroWhatsApp}?text=${encodeURIComponent(mensaje)}`;
    
    window.open(url, '_blank');
}
</script>


<style>
 #modalPago{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:9999;align-items:center;justify-content:center}
 #modalPago.abierto{display:flex}
 #modalPago .caja{background:#fff;border-radius:12px;padding:24px;width:92%;max-width:400px}
 #modalPago input{width:100%;padding:10px;margin:6px 0 12px;border:1px solid #ccc;border-radius:6px;box-sizing:border-box}
 #modalPago .fila{display:flex;gap:10px}
 #modalPago .acciones{display:flex;gap:10px;margin-top:6px}
 #modalPago button{flex:1;padding:12px;border:none;border-radius:8px;cursor:pointer;font-weight:bold}
 #btnConfirmarPago{background:#f29b2e;color:#fff}
 #btnCancelarPago{background:#eee}
 #msgPago{margin-top:10px;font-size:14px}
 .ayuda-test{font-size:12px;color:#666;background:#f6f6f6;padding:8px;border-radius:6px}
</style>
<div id="modalPago">
  <div class="caja">
    <h3>Pago con tarjeta (modo prueba)</h3>
    <p class="ayuda-test">Tarjeta de prueba: <b>4242 4242 4242 4242</b> (aprobada).<br>
      <b>4000 0000 0000 0002</b> = declinada · <b>4000 0000 0000 9995</b> = sin fondos.<br>Vence: cualquier fecha futura (ej. 12/30), CVV: 123.</p>
    <label>Número de tarjeta</label>
    <input id="pagoNumero" inputmode="numeric" maxlength="19" placeholder="4242 4242 4242 4242" autocomplete="off">
    <div class="fila">
      <div><label>Vence (MM/AA)</label><input id="pagoVence" maxlength="5" placeholder="12/30" autocomplete="off"></div>
      <div><label>CVV</label><input id="pagoCvv" maxlength="4" placeholder="123" autocomplete="off"></div>
    </div>
    <div class="acciones">
      <button id="btnCancelarPago" type="button" onclick="cerrarPago()">Cancelar</button>
      <button id="btnConfirmarPago" type="button" onclick="confirmarPago()">Pagar</button>
    </div>
    <div id="msgPago"></div>
  </div>
</div>

<script>
const USUARIO_LOGUEADO = <?php echo $logueado ? 'true' : 'false'; ?>;

// Compra solo con sesión iniciada: si no, se manda al login y se vuelve al carrito después
function exigirSesion() {
    if (USUARIO_LOGUEADO) return true;
    alert("Debes iniciar sesión para realizar una compra.");
    window.location.href = "login.php?volver=carrito.php";
    return false;
}

function abrirPago() {
    if (!exigirSesion()) return;
    const carrito = JSON.parse(localStorage.getItem('carrito')) || [];
    if (carrito.length === 0) { alert("Tu carrito está vacío."); return; }
    document.getElementById('msgPago').textContent = '';
    document.getElementById('modalPago').classList.add('abierto');
}
function cerrarPago() { document.getElementById('modalPago').classList.remove('abierto'); }

async function confirmarPago() {
    const msg = document.getElementById('msgPago');
    const btn = document.getElementById('btnConfirmarPago');
    const carrito = JSON.parse(localStorage.getItem('carrito')) || [];
    // Solo mandamos id y cantidad: el servidor lee los precios de la BD
    const items = carrito.map(i => ({ id: i.id, cantidad: i.cantidad }));
    const pago = {
        numero: document.getElementById('pagoNumero').value,
        vencimiento: document.getElementById('pagoVence').value,
        cvv: document.getElementById('pagoCvv').value
    };

    btn.disabled = true; msg.style.color = '#666'; msg.textContent = 'Procesando pago…';
    try {
        const r = await fetch('procesar_compra.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ items, pago })
        });
        const data = await r.json();
        if (data.login) { window.location.href = 'login.php'; return; }
        if (!data.ok) { msg.style.color = '#dc2626'; msg.textContent = data.error; btn.disabled = false; return; }

        localStorage.removeItem('carrito');
        msg.style.color = '#16a34a';
        msg.textContent = '¡Pago aprobado! Pedido #' + data.pedido_id + ' (ref. ' + data.referencia + ')';
        setTimeout(() => { window.location.href = 'mis_pedidos.php'; }, 1800);
    } catch (e) {
        msg.style.color = '#dc2626'; msg.textContent = 'No se pudo conectar con el servidor.'; btn.disabled = false;
    }
}
</script>

<script src="js/analitica.js"></script>
<script src="js/chatbot.js"></script>
</body>
</html>