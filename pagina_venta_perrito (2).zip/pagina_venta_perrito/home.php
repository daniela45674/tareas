<?php
session_start();
// Incluir la conexión a la base de datos
include 'conexion.php';

// Consultar únicamente los productos que están marcados en oferta (en_oferta = 1)
$sql_ofertas = "SELECT * FROM productos WHERE en_oferta = 1 AND activo = 1 ORDER BY id DESC";
$resultado_ofertas = $conexion->query($sql_ofertas)->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patitas Felices - Alimento, juguetes, camas y accesorios para mascotas</title>
    <meta name="description" content="Tienda en línea de productos para mascotas: alimento, juguetes, camas y accesorios con ofertas y envíos a todo el Perú. Compra por la web o por WhatsApp.">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/style_footer.css">
</head>
<body>

<!-- HEADER ESTÁTICO -->
<header class="header">
    <div class="logo">
        <img src="imagenes/otras_imagenes/logo2.jpg" alt="Logo Patitas Felices">
        <span>Patitas Felices</span>
    </div>

    <div id="hamburger" class="hamburger">
        <span></span>
        <span></span>
        <span></span>
    </div>

    <!-- BARRA DE BÚSQUEDA -->
    <div class="buscador-container">
        <input type="text" id="inputBuscar" placeholder="buscar" class="input-buscar">
    </div>

    <?php $paginaActual = 'home'; include 'includes/nav.php'; ?>
</header>

<!-- HERO -->
<section class="hero" style="background-image: url('imagenes/otras_imagenes/fondo1.jpeg')">
  <div class="contenido-hero">
    <h1>Patitas Felices</h1>
    <p>Detrás de cada movimiento, una historia...</p>
    <p>Pagina de daniela</p>
  </div>
</section>

<!-- CARRUSEL MULTIIMAGEN DINÁMICO -->
<section class="carrusel-multi">
    <h2>Nuestras Ofertas</h2>

    <button class="btn prev" id="prev">&#10094;</button>

    <div class="contenedor-multi" id="contenedorMulti">
        <?php if (!empty($resultado_ofertas)): ?>
            <?php foreach ($resultado_ofertas as $prod): ?>
                <div class="slide-multi">
                    <?php if (!empty($prod['imagen'])): ?>
                        <img src="imagenes/productos/<?php echo htmlspecialchars($prod['imagen']); ?>" alt="<?php echo htmlspecialchars($prod['nombre']); ?>">
                    <?php else: ?>
                        <img src="imagenes/productos/default.png" alt="Sin imagen">
                    <?php endif; ?>
                    <!-- Opcional: Puedes mostrar el nombre o precio dentro o debajo del slide si tu diseño lo permite -->
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p style="text-align: center; width: 100%; padding: 20px;">No hay ofertas disponibles en este momento. ¡Vuelve pronto!</p>
        <?php endif; ?>
    </div>

    <button class="btn next" id="next">&#10095;</button>
</section>

<section class="banner-pago">
  <img src="imagenes/otras_imagenes/baner_pago.jpg" alt="Métodos de pago">
</section>

<section class="info-tarjetas">
    <!-- TARJETA 1 -->
    <div class="tarjeta">
        <img src="imagenes/otras_imagenes/tarjeta1.jpg" alt="Tienda Superpet">
        <h3>Superpet – Tienda física y online</h3>
        <p>
            Somos la cadena de tiendas para mascotas más grande del Perú, 
            con más de 40 locales, delivery express y miles de productos 
            para hacer feliz a tu engreído.
        </p>
    </div>

    <!-- TARJETA 2 -->
    <div class="tarjeta">
        <img src="imagenes/otras_imagenes/tarjeta2.jpg" alt="Cuidado de mascotas">
        <h3>Todo para su bienestar</h3>
        <p>
            Alimentos premium, juguetes resistentes, accesorios, medicamentos 
            y todo lo necesario para que tu mascota sea feliz y saludable.
        </p>
    </div>

    <!-- TARJETA 3 -->
    <div class="tarjeta">
        <img src="imagenes/otras_imagenes/tarjeta3.jpg" alt="Delivery rápido">
        <h3>Delivery rápido y seguro</h3>
        <p>
            Llegamos a Lima, Arequipa, Chiclayo, Trujillo y Piura.  
            Delivery gratis desde S/90 y delivery express en menos de 2 horas.
        </p>
    </div>

    <!-- TARJETA 4 -->
    <div class="tarjeta">
        <img src="imagenes/otras_imagenes/tarjeta4.jpg" alt="Comida para mascotas">
        <h3>Alimento especializado</h3>
        <p>
            Trabajamos con marcas líderes como Canbo, Dogxtreme, Hills, Pro Plan 
            y Royal Canin. También tenemos fórmulas especiales para cada necesidad.
        </p>
    </div>

    <!-- TARJETA 5 -->
    <div class="tarjeta">
        <img src="imagenes/otras_imagenes/tarjeta5.webp" alt="Higiene de mascotas">
        <h3>Higiene y cuidado</h3>
        <p>
            Arenas, pañales, shampoos, cepillos, antipulgas, vitaminas y todo lo 
            necesario para mantener a tu mascota limpia y protegida.
        </p>
    </div>

    <!-- TARJETA 6 -->
    <div class="tarjeta">
        <img src="imagenes/otras_imagenes/tarjeta6.jpg" alt="Diversión para mascotas">
        <h3>Diversión asegurada</h3>
        <p>
            Juguetes Kong, rascadores, peluches y miles de accesorios para que 
            tu mascota nunca se aburra.
        </p>
    </div>
</section>

<!-- INTRODUCCIÓN -->
<section class="introduccion">
    <h2 class="titulo">Vida con Mascotas</h2>
    <p>
        Detrás de cada juego hay una complicidad única.  
        Detrás de cada ladrido, maullido o pequeño gesto, existe un cariño que transforma nuestro día.
    </p>
    <p>
        Las mascotas llegan para llenarnos de compañía, alegría y momentos inolvidables.  
    </p>
</section>

<!-- SECCIÓN 5 - ¿POR QUÉ ELEGIRNOS? -->
<div class="seccion-elegirnos">
    <h2>¿Por qué elegirnos?</h2>
    <div class="elegirnos-grid">
        <div class="elegirnos-item">
            <div class="elegirnos-icon">🐾</div>
            <h3>Amor por los Animales</h3>
            <p>Tu mascota es parte de tu familia y merece lo mejor siempre.</p>
        </div>
        <div class="elegirnos-item">
            <div class="elegirnos-icon">🚚</div>
            <h3>Delivery Seguro</h3>
            <p>Envíos rápidos a diferentes regiones del Perú.</p>
        </div>
        <div class="elegirnos-item">
            <div class="elegirnos-icon">⭐</div>
            <h3>Alta Calidad</h3>
            <p>Solo trabajamos con las mejores marcas del mercado.</p>
        </div>
        <div class="elegirnos-item">
            <div class="elegirnos-icon">💰</div>
            <h3>Mejores Precios</h3>
            <p>Ofrecemos precios justos y ofertas durante toda la semana.</p>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>

<!-- ENLACE AL SCRIPT EXTERNO -->
<script src="js/script.js"></script>

<script src="js/analitica.js"></script>
<script src="js/chatbot.js"></script>
</body>
</html>